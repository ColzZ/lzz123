const webpack = require('webpack');
const webpackDevMiddleware = require('webpack-dev-middleware');
const webpackHotMiddleware = require('webpack-hot-middleware');
const webpackConfig = require('./webpack.config');
const { host, port, devPublicPath, i18n } = require('./config');
const Express = require('express');
const fs = require('fs');
const glob = require('glob');

const app = new Express();
const compiler = webpack(webpackConfig);
const devMiddleware = webpackDevMiddleware(
  compiler, { noInfo: true, publicPath: `http://${host}:${port}/${devPublicPath}/` }
);

app.use(devMiddleware);
app.use(webpackHotMiddleware(compiler));

app.use('/static', Express.static('dist/static'));
app.use((req, res) => {
  res.sendFile(`${__dirname}/dist/index.html`);
});

app.listen(port, error => {
  if (error) {
    console.error(error);
  } else {
    console.info('==> ENV: %s, Listening on port %s. Open up http://%s:%s/ in your browser.', process.env.NODE_ENV, port, host, port);
  }
});

// 国际化动态变更监控
if (i18n && i18n.watch) {
  let odd = false;
  glob(`${i18n.path}/*.json`, (err, files) => {
    files.forEach(file => {
      fs.watch(file, eventType => {
        if (eventType !== 'change') return;

        odd = !odd;
        if (odd) return;

        try {
          const content = fs.readFileSync(file);
          JSON.parse(content);
          console.log('正在重新编译语言包...');
          devMiddleware.invalidate();
        } catch (e) {
          console.log('语言包格式错误', file);
        }
      });
    });
  });
}
