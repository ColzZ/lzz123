const path = require('path');
const glob = require('glob');
const webpack = require('webpack');
const WebpackShellPlugin = require('webpack-shell-plugin');
const I18nPlugin = require('./scripts/tools/i18n-webpack-plugin');
const ExtractTextPlugin = require('extract-text-webpack-plugin');

const { host, port, devPublicPath, prodPublicPath, i18n, ie8, hmr } = require('./config');

const nodeModulesDir = path.join(__dirname, 'node_modules');

const extractCss = new ExtractTextPlugin('[name].css');

// 排除编译的第三方库（为了兼容IE8，部分必须进行es3编译）
const deps = [
  // 'babel-polyfill/dist/polyfill.min.js',
  'echarts/build/echarts-all.js',
  'jquery/dist/jquery.min.js',
  // 'jquery.scrollbar/jquery.scrollbar.min.js',
  // 'lodash/lodash.min.js',
  // 'react/dist/react.min.js',
  // 'react-bootstrap/dist/react-bootstrap.min.js',
  // 'react-dom/dist/react-dom.min.js',
  'react-redux/dist/react-redux.min.js',
  // 'react-router/dist/react-router.min.js',
  // 'react-router-redux/dist/ReactRouterRedux.min.js',
  'redux/dist/redux.min.js',
  // 'redux-thunk/dist/redux-thunk.min.js',
];

// 第三方库
const vendor = [
  'babel-polyfill',
  'echarts',
  // 'echarts/chart/chord',
  // 'echarts/chart/gauge',
  'jquery',
  'jquery.scrollbar',
  'lodash',
  'querystring',
  // 'rc-echarts',
  'react',
  // 'react-addons-css-transition-group',
  // 'react-bootstrap',
  'react-dom',
  // 'react-loaders',
  'react-redux',
  'react-router',
  'react-router-redux',
  'redux',
  'redux-thunk',
];

let entry;
let publicPath;
let plugins;

const { NODE_ENV } = process.env;

if (NODE_ENV === 'production') {
  entry = {
    app: './src/entry',
    vendor,
  };
  publicPath = prodPublicPath;
  plugins = [
    new webpack.DefinePlugin({
      'process.env.NODE_ENV': JSON.stringify(NODE_ENV),
    }),
    // new webpack.NoErrorsPlugin(),
    // new webpack.optimize.OccurrenceOrderPlugin(),
    // new webpack.optimize.UglifyJsPlugin({
    //   output: {
    //     comments: false,  // remove all comments
    //   },
    //   compress: {
    //     warnings: false,
    //   },
    // }),
    new webpack.optimize.CommonsChunkPlugin('vendor', 'vendor.js'),
    extractCss,
    new WebpackShellPlugin({
      onBuildExit: [`xcopy "${__dirname}\\dist\\*.*" "${__dirname}\\..\\web\\assets" /s /e /y`],
    }),
  ];

  if (!ie8) {
    plugins.push(new webpack.optimize.DedupePlugin());
  }
} else {
  entry = {
    app: [
      './src/entry',
    ],
    vendor,
  };
  publicPath = `http://${host}:${port}/${devPublicPath}/`;
  plugins = [
    new webpack.DefinePlugin({
      'process.env.NODE_ENV': JSON.stringify(NODE_ENV || 'development'),
    }),
    new webpack.optimize.CommonsChunkPlugin('vendor', 'vendor.js'),
    extractCss,
  ];

  // IE8 不支持热替换模式
  if (!ie8) {
    if (hmr) {
      entry.app.push(`webpack-hot-middleware/client?path=http://${host}:${port}/__webpack_hmr`);
    }
    plugins.push(new webpack.HotModuleReplacementPlugin());
  }
}

let config = {
  // devtool: 'source-map',
  entry,
  output: {
    path: path.join(__dirname, 'dist/app'),
    publicPath,
    filename: '[name].js',
    chunkFilename: '[id].chunk.js',
  },
  plugins,
  resolve: {
    alias: {},
    extensions: ['', '.webpack.js', '.web.js', '.js', '.less', '.css'],
    root: [
      path.resolve(__dirname, './src/app/utils'),
    ],
  },
  module: {
    noParse: [],
    preLoaders: [
      {
        test: /\.js$/,
        loader: 'eslint-loader',
        exclude: [/node_modules/, /loading/],
      },
    ],
    loaders: [
      {
        test: /\.js$/,
        include: [
          path.join(__dirname, 'src'),
          /react/,
        ],
        loaders: ['es3ify-loader', 'babel-loader'],
      },
      {
        test: /\.css$/,
        include: path.join(__dirname, 'src'),
        // loaders: ['style-loader', 'css-loader'],
        loader: extractCss.extract('css-loader'),
      },
      {
        test: /\.less$/,
        include: path.join(__dirname, 'src'),
        // loaders: ['style-loader', 'css-loader', 'less-loader'],
        loader: extractCss.extract(['css-loader', 'less-loader']),
      },
      {
        test: /\.(jpe?g|png|gif|eot|woff2|woff|ttf|svg)$/,
        include: path.join(__dirname, 'src'),
        loader: 'url-loader?limit=8192',
      },
      {
        test: /\.coffee$/,
        loaders: ['coffee-loader'],
        include: path.join(__dirname, 'src'),
      },
    ],
  },
  babel: {
    presets: ['latest', 'react'],
    plugins: [
      require('babel-plugin-transform-object-rest-spread'),
      require('babel-plugin-transform-class-properties'),
    ],
    env: {
      development: {
        presets: !ie8 && hmr ? ['react-hmre'] : [],
      },
    },
  },
};

deps.forEach(dep => {
  const depPath = path.resolve(nodeModulesDir, dep);
  config.resolve.alias[dep.split('/')[0]] = depPath;
  config.module.noParse.push(depPath);
});

// 国际化配置
if (i18n) {
  const languages = glob.sync(`${i18n.path}/*.json`);

  config = languages.map(file => {
    const language = path.basename(file, '.json');
    return Object.assign({}, config, {
      name: language,
      output: Object.assign({}, config.output, {
        filename: `${language}.[name].js`,
      }),
      plugins: [
        ...config.plugins,
        new I18nPlugin(file, { nested: true, watch: NODE_ENV === 'development' && i18n.watch }),
      ],
    });
  });
}

module.exports = config;
