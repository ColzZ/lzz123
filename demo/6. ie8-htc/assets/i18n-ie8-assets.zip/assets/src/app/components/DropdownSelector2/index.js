import React, { PropTypes, Component } from 'react';

import './style';

import DropdownMenu from '../DropdownMenu';
import DropdownPanel from '../DropdownPanel';

export default class DropdownSelector extends Component {
  static propTypes = {
    className: PropTypes.string,
    multiple: PropTypes.bool,
    options: PropTypes.array.isRequired,
    required: PropTypes.bool,
    onSelect: PropTypes.func.isRequired,
    placeholder: PropTypes.string,
    title: PropTypes.string,
    selectedPlaceholder: PropTypes.string,
    getContent: PropTypes.func.isRequired,
    getSelectedOptions: PropTypes.func.isRequired,
    disabled: PropTypes.bool,
    menuWidth: PropTypes.number,
    dropdownDirection: PropTypes.string,
  }

  static chilrendShouldComponentUpdateProps(props, nextProps) {
    return (
      props.className !== nextProps.className ||
      props.multiple !== nextProps.multiple ||
      props.required !== nextProps.required ||
      props.onSelect !== nextProps.onSelect ||
      props.disabled !== nextProps.disabled ||
      props.options !== nextProps.options
    );
  }

  constructor(props) {
    super(props);

    const { options } = props;

    this.state = {
      // 被操作的选项数据
      options,

      // 原始选项数据，
      // 用于不点确定就关闭弹出框时，还原之前状态。
      originalOptions: options,

      inited: false,
    };
  }

  componentWillReceiveProps(nextProps) {
    this.onComponentWillReceiveProps(nextProps);
  }

  shouldComponentUpdate(nextProps, nextState) {
    return (
      this.state.originalOptions !== nextState.originalOptions ||
      this.state.options !== nextState.options ||
      this.state.inited !== nextState.inited ||
      this.shouldComponentUpdateProps(nextProps)
    );
  }

  onComponentWillReceiveProps(nextProps) {
    const { options } = nextProps;

    // 外部 options 变更时更新本地 options 与 originalOptions
    if (this.props.options !== options) {
      this.setState({ originalOptions: options, options });
    }
  }

  /**
   * 获取已确定选择项个数
   * @return {number} 已确定选择项个数
   */
  getSelectedOriginalOptionsCount() {
    const { originalOptions } = this.state;
    const ids = this.getSelectedIds(originalOptions);
    return ids ? ids.split(',').length : 0;
  }

  /**
   * 获取当前弹框的已选项（已选但未被确定的选项）个数
   * @return {number} 当前弹框的已选项（已选但未被确定的选项）个数
   */
  getSelectedOptionsCount() {
    const { options } = this.state;
    const ids = this.getSelectedIds(options);
    return ids ? ids.split(',').length : 0;
  }

  getSelectedTexts = options => (
    this.props.getSelectedOptions(options).map(option => option.text).join(',')
  )

  getSelectedIds = options => (
    this.props.getSelectedOptions(options).map(option => option.id).join(',')
  )

  getSelectedLevel = options => {
    const selectedOptions = this.props.getSelectedOptions(options);
    return selectedOptions.length > 0 ? selectedOptions[0].level : undefined;
  }

  getToggleText(selectedCount) {
    if (selectedCount === 1) {
      const { originalOptions } = this.state;
      return this.getSelectedTexts(originalOptions);
    } else if (selectedCount > 1) {
      return `${this.props.selectedPlaceholder || '已选'}(${selectedCount})`;
    }
    return '';
  }

  /**
   * 获取当前 Tab 提示内容
   */
  getTips() {
    if (this.props.required && !this.getSelectedOptionsCount()) {
      return '请至少选择一个有效选项';
    }
    return '';
  }

  setOptions = options => {
    this.setState({ options });
    return options;
  }

  submited = false

  shouldComponentUpdateProps(nextProps) {
    return (
      this.props.className !== nextProps.className ||
      this.props.multiple !== nextProps.multiple ||
      this.props.required !== nextProps.required ||
      this.props.onSelect !== nextProps.onSelect ||
      this.props.placeholder !== nextProps.placeholder ||
      this.props.title !== nextProps.title ||
      this.props.selectedPlaceholder !== nextProps.selectedPlaceholder ||
      this.props.getContent !== nextProps.getContent ||
      this.props.getSelectedOptions !== nextProps.getSelectedOptions ||
      this.props.disabled !== nextProps.disabled ||
      this.props.menuWidth !== nextProps.menuWidth
    );
  }

  /**
   * 用于改变选项但没有点击确定就关闭弹出框时，
   * 还原之前已被确定的选项状态
   */
  restore = () => {
    const { originalOptions } = this.state;

    // 如果上次操作没有提交，还原选择状态
    if (!this.submited) {
      this.setState({
        options: originalOptions,
      });
    } else {
      this.submited = false;
    }

    this.setState({ inited: true });
  }

  open = () => {
    this.restore();
    if (this.refContent.onOpen) {
      this.refContent.onOpen();
    }
  }

  close = () => {
    if (this.refContent.onClose) {
      this.refContent.onClose();
    }
  }

  submit = () => {
    const { options } = this.state;
    const { required } = this.props;
    const ids = this.getSelectedIds(options);

    if (required && !ids) return;

    // 提交时，将已选但未确定的状态更新为实际选择状态
    this.setState({
      originalOptions: options,
    });
    this.submited = true;
    const texts = this.getSelectedTexts(options);
    this.props.onSelect(
      {
        ids,
        texts,
      },
      this.props.getSelectedOptions(options),
      options,
    );

    this.refElm.handleClose();
  }

  render() {
    const { options, inited } = this.state;
    const {
      className = '',
      multiple,
      placeholder,
      title,
      getContent,
      disabled,
      menuWidth,
      dropdownDirection,
    } = this.props;

    const selectedCount = this.getSelectedOriginalOptionsCount();
    const toggleText = this.getToggleText(selectedCount);
    const tips = this.getTips();

    return (
      <DropdownMenu
        multiple={multiple}
        className={`dropdown-menu-selector ${className}`}
        popoverWidth={menuWidth || 600}
        onOpen={this.open}
        onClose={this.close}
        text={toggleText}
        ref={ref => { this.refElm = ref; }}
        placeholder={placeholder}
        hasSelected={selectedCount > 0}
        disabled={disabled}
        dropdownDirection={dropdownDirection}
      >
        {inited ?
          <DropdownPanel
            title={title}
            onSubmit={this.submit}
            multiple={multiple}
            footerTips={tips}
          >
            {getContent({
              ...this.props,
              options,
              setOptions: this.setOptions,
              ref: ref => {
                if (ref) {
                  this.refContent = ref;
                }
              },
            })}
          </DropdownPanel> : <div />
        }
      </DropdownMenu>
    );
  }
}
