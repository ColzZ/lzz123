import _ from 'lodash';
import React, { Component, PropTypes } from 'react';

import './style';

export default class DownloadExcel extends Component {
  static propTypes = {
    style: PropTypes.object,
    className: PropTypes.string,
    type: PropTypes.string,
    href: PropTypes.string.isRequired,
    data: PropTypes.object,
    text: PropTypes.string,
  }

  shouldComponentUpdate(nextProps) {
    return (
      !_.isEqual(this.props.style, nextProps.style) ||
      this.props.className !== nextProps.className ||
      this.props.type !== nextProps.type ||
      this.props.href !== nextProps.href ||
      !_.isEqual(this.props.data, nextProps.data) ||
      this.props.text !== nextProps.text
    );
  }

  render() {
    const { className = '', href, type = 'get', data, text } = this.props;

    if (type === 'post') {
      // 生成一个临时id
      // const id = String(Math.random()).substring(2);

      return (
        <a className={`download-excel ${className}`} onClick={() => this.refForm.submit()}>
          {text && <span className="text">{text}</span>}
          <form ref={ref => { this.refForm = ref; }} action={href} method={type} target="_self" style={{ display: 'none' }}>
            {Object.keys(data).map(key => {
              const value = data[key];
              return <input key={key} type="hidden" name={key} value={value} />;
            })}
          </form>
          {/*
          <div style={{ display: 'none' }}>
            <iframe
              src="about:blank"
              id={`__hidden_iframe_${id}__`}
              name={`__hidden_iframe_${id}__`} />
            <form ref={ref => { this.refForm = ref; }} action={href} method={type} target="_self">
              {Object.keys(data).map(key => {
                const value = data[key];
                return <input key={key} type="hidden" name={key} value={value} />;
              })}
            </form>
          </div>
          */}
        </a>
      );
    }
    return (
      <a className={`download-excel ${className}`} href={href}>
        {text && <span className="text">{text}</span>}
      </a>
    );
  }
}
