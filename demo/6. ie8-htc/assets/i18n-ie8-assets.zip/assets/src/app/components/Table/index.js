import _ from 'lodash';
import $ from 'jquery';
import React, { Component, PropTypes } from 'react';
import 'jquery.scrollbar';
import './style';
import Td from './Td';

const TableTips = ({ children, style }) => (
  <div className="table-tips" style={style}>
    <div className="table-tips-content">
      {children}
    </div>
  </div>
);

TableTips.propTypes = {
  children: PropTypes.node.isRequired,
  style: PropTypes.object.isRequired,
};

class Table extends Component {
  static propTypes = {
    className: PropTypes.string,
    options: PropTypes.object.isRequired,
    style: PropTypes.object,
    children: PropTypes.node,
    loading: PropTypes.bool,
    fixedTableAside: PropTypes.node,
    freezeHeader: PropTypes.bool,
    freezeColumn: PropTypes.number,
    scrollY: PropTypes.oneOfType([PropTypes.string, PropTypes.number, PropTypes.bool]),
    visibleColumns: PropTypes.array,
    autoExpand: PropTypes.bool,
    pagination: PropTypes.func,
    ppNumber: PropTypes.number,
  }

  constructor(props) {
    super(props);
    this.state = {
      loading: Boolean(props.loading),
      colsWidth: [],
      options: props.options || [],
      page: 1,
      hasMorePage: true,
      tableWidth: 0,
    };
  }

  componentDidMount() {
    const {
      freezeHeader,
      freezeColumn,
      scrollY,
      style,
    } = this.props;

    const $refTableWrapper = $(this.refTableWrapper);
    const $dataTableScroller = $(this.refDataTableScroller);

    if (freezeHeader || freezeColumn) {
      const $fixedTableHeaderScroller = $(this.refFixedTableHeaderScroller);

      $dataTableScroller.on('scroll', () => {
        $fixedTableHeaderScroller.scrollLeft($dataTableScroller.scrollLeft());
      });

      // 表格内容先宽后窄，会出现内容无法伸展填满表格区域的现象，
      // 这里的超时是为了修复该问题，以期获取最后真实的表格宽度
      setTimeout(() => {
        this.tableWidth = $refTableWrapper.width() - 2;
      }, 0);
    }

    if (freezeColumn) {
      const $fixedTableAsideScroller = $(this.refFixedTableAsideScroller);

      $dataTableScroller.on('scroll', () => {
        $fixedTableAsideScroller.scrollTop($dataTableScroller.scrollTop());
      });

      $fixedTableAsideScroller.on('mousewheel', event => {
        const { deltaY, wheelDelta } = event.originalEvent;
        const y = deltaY || -wheelDelta;
        $dataTableScroller.scrollTop($dataTableScroller.scrollTop() + y);
      });
    }

    if (scrollY || (style && style.height)) {
      const $hasMoreButton = $(this.refHasMoreButton);
      $dataTableScroller.scrollbar({
        onScroll: (yBar, xBar) => {
          $hasMoreButton.css({ 'margin-left': xBar.scroll });
        },
      });
    }
  }

  componentWillReceiveProps(nextProps) {
    const prevOptions = this.props.options;
    const { options, pagination, ppNumber = 10 } = nextProps;
    if (prevOptions !== options) {
      let { page, hasMorePage } = this.state;

      if (pagination) {
        const currRowsLength = options.data.length;
        const prevRowsLength = prevOptions.data.length;
        const currPageDataNumber = currRowsLength - prevRowsLength;

        // 重新填数，分页变量重置为第一页。
        if (
          // 新数据比旧数据长度要短
          currPageDataNumber < 0 ||
          // 新数据比旧数据长度要长，且当前纪录条数小于每页最大纪录数，且非第一次加载数据
          (currPageDataNumber > 0 && currRowsLength <= ppNumber && prevRowsLength > 0)
        ) {
          page = 1;
        }

        // 判断是否有下一页
        if (page === 1) {
          hasMorePage = currRowsLength === ppNumber;
        } else {
          hasMorePage = currPageDataNumber === ppNumber;
        }
      }

      this.setState({ options, loading: false, page, hasMorePage });
      this.freeze(options);

      // 新配置表格宽度小于原配置表格宽度时，
      // 滚动条无法自动重置，导致滚动位置超过可滚动最大限制，
      // 会出现内容错位，下面这段代码是用来手动强制重置的。
      setTimeout(() => {
        // 配置变更时，重置滚动位置
        const $dataTableScroller = $(this.refDataTableScroller);
        const maxScrollLeft = $(this.refDataTable).outerWidth() - this.tableWidth;
        if ($dataTableScroller.scrollLeft() > maxScrollLeft) {
          $dataTableScroller.scrollLeft(maxScrollLeft);
        }
      }, 0);
    }
  }

  shouldComponentUpdate(nextProps, nextState) {
    return (
      this.state.tableWidth !== nextState.tableWidth ||
      this.state.options !== nextState.options ||
      this.props.visibleColumns !== nextProps.visibleColumns
    );
  }

  getVisibleChildrenColumns(columns) {
    return _.flatten(columns.filter(column => column.children)
      .map(column => column.children));
  }

  getVisibleColumns(columns) {
    if (!columns) return [];

    const { visibleColumns } = this.props;
    const children = this.getVisibleChildrenColumns(columns);
    let childrenColumns = [];
    if (children.length > 0) {
      childrenColumns = this.getVisibleColumns(children);
    }
    return columns.filter((column, index) => (
      !column.children &&
      (column.visible === undefined ||
      (column.visible !== undefined && visibleColumns.includes(index)))
    )).concat(childrenColumns);
  }

  getVisibleTbodyColumns(columns) {
    if (!columns) return [];

    const { visibleColumns } = this.props;
    let nextColumns = [];

    columns.forEach((column, index) => {
      const { children, visible } = column;
      if (!children) {
        if (
          visible === undefined ||
          (visible !== undefined && visibleColumns.includes(index))
        ) {
          nextColumns.push(column);
        }
      } else {
        nextColumns = nextColumns.concat(this.getVisibleTbodyColumns(children));
      }
    });

    return nextColumns;
  }

  getVisibleHeads() {
    const { options: { columns = [] } } = this.state;
    const { visibleColumns } = this.props;
    return columns.filter((column, index) => (
      column.visible === undefined ||
      (column.visible !== undefined && visibleColumns.includes(index))
    ));
  }

  getTbody(data, columns, arrayMode, freezeColumn, drillLevel, isRoot) {
    const { autoExpand } = this.props;
    if (isRoot) this.rowIndex = -1;

    return data.map(row => {
      const { expanded } = row;
      this.rowIndex += 1;
      let result = [
        <tr
          key={row.id}
          onClick={row.onClick && (() => row.onClick(row.id))}
          className={`${row.className || ''} ${this.rowIndex % 2 === 0 ? 'odd' : 'even'}`}
        >
          {columns.map(({ key, render, className, style, drillPoint }, colIndex) => {
            if (freezeColumn && colIndex > freezeColumn - 1) return undefined;
            const data = row[arrayMode ? colIndex : key] || '';
            const coordinate = {
              row: this.rowIndex,
              col: colIndex,
            };

            const isObject = typeof data === 'object';
            if ((!isObject && data !== undefined) || (isObject && !_.isEmpty(data))) {
              return (
                <Td
                  key={colIndex}
                  className={className}
                  style={style}
                  data={data}
                  render={render}
                  rowData={row}
                  coordinate={coordinate}
                  drillPoint={drillPoint}
                  drillLevel={drillLevel}
                  autoExpand={autoExpand}
                  onDrill={this.drill}
                  expanded={expanded}
                />
              );
            }
            return undefined;
          })}
        </tr>,
      ];
      if (row.children && row.children.length > 0) {
        if (((autoExpand && expanded === undefined) || expanded)) {
          result = [...result, this.getTbody(
            row.children, columns, arrayMode, freezeColumn, drillLevel + 1
          )];
        } else {
          this.rowIndex += row.children.length;
        }
      }
      return result;
    });
  }

  getDefaultHeader(columns) {
    const trs = [
      <tr key={0}>
        {columns.map((column, index) => {
          const { title, titleRender, rowSpan, colSpan, titleStyle = {}, titleClassName = '' } = column;
          return (
            <th
              key={index}
              rowSpan={rowSpan}
              colSpan={colSpan}
              style={titleStyle}
              className={titleClassName}
            >
              {!titleRender ?
                title :
                titleRender(title, column)
              }
            </th>
          );
        })}
      </tr>,
    ];

    const childrenColumns = this.getVisibleChildrenColumns(columns);
    if (childrenColumns.length > 0) {
      trs.push(this.getDefaultHeader(childrenColumns));
    }

    return trs;
  }

  getCalculateColumns(columns, isRoot) {
    let ccols = [];
    if (isRoot) this.ccolCount = -1;
    columns.forEach(column => {
      if (column.children) {
        ccols = ccols.concat(this.getCalculateColumns(column.children));
      } else {
        this.ccolCount += 1;
        if (this.widths) {
          ccols.push(
            <th key={this.ccolCount} style={{ width: this.widths[this.ccolCount] }} />
          );
        } else {
          ccols.push(<th key={this.ccolCount} />);
        }
      }
    });
    return ccols;
  }

  getTableHeader(columns) {
    const { children } = this.props;
    const hasCustomHeader = children && children.type === 'thead';

    if (hasCustomHeader) {
      const c = children.props.children;
      (c.length ? c : [c]).push(
        <tr className="calculate-width-row">
          {columns.map((column, index) => (
            <th key={index} />
          ))}
        </tr>
      );
      return children;
    }

    return (
      <thead>
        {this.getDefaultHeader(columns)}
        <tr className="calculate-width-row">
          {this.getCalculateColumns(columns, true)}
        </tr>
      </thead>
    );
  }

  getFreezeHeaderAside(columns) {
    const { fixedTableAside, freezeColumn } = this.props;

    const calculateWidthRow = (
      <tr className="calculate-width-row">
        {columns.slice(0, freezeColumn).map((column, index) => (
          <th key={index} />
        ))}
      </tr>
    );

    if (fixedTableAside) {
      fixedTableAside.props.children.push(calculateWidthRow);
    }

    return (
      fixedTableAside ||
        <thead>
          <tr>
            {columns.map(({ title, rowSpan, colSpan, titleStyle = {}, titleClassName = '' }, index) => {
              if (index > freezeColumn - 1) return undefined;
              return (
                <th
                  key={index}
                  rowSpan={rowSpan}
                  colSpan={colSpan}
                  style={titleStyle}
                  className={titleClassName}
                >
                  {title}
                </th>
              );
            })}
          </tr>
          {calculateWidthRow}
        </thead>
    );
  }

  freeze = options => {
    const { columns } = options;
    const { freezeHeader, freezeColumn } = this.props;

    if (!columns || (!freezeHeader && !freezeColumn)) return;

    const visibleColumns = this.getVisibleTbodyColumns(columns);

    if (visibleColumns.length === 0) return;

    setTimeout(() => {
      let tableWidth = 0;
      const ths = 'thead tr.calculate-width-row th';
      const $table = $(this.refDataTable);
      const $ths = $table.find(ths);
      const $fixedTableHeader = $(this.refFixedTableHeader);
      const $fixedHeaderThs = $fixedTableHeader.find(ths);
      const $fixedAsideThs = $(this.refFixedTableAside).find(ths);
      const $fixedHeaderAsideThs = $(this.refFixedTableHeaderAside).find(ths);

      // 由于 IE8 下固定宽度 th 无法自适应固定宽度 table ，这里必须清除 th 原有宽度，
      // 以使 th 重新适应 table 宽度，主要用于解决列数过少时无法填满整个 table 区域
      // 的问题，注：其它现代浏览器无该问题。
      $ths.each(function () {
        $(this).css({ width: 'auto' });
      });
      $table.outerWidth(this.tableWidth);

      // 第一步
      // 如果列设置了宽度以列宽为准，否则以实际宽度为准
      $ths.each(function (index) {
        const width = visibleColumns[index].width || $(this).outerWidth();
        $(this).outerWidth(width);
        tableWidth += width;
      });

      // 设置表格宽度，如果表格宽度小于表格可见区域宽度，
      // 以可见区域宽度为准
      if (tableWidth < this.tableWidth) tableWidth = this.tableWidth;
      $table.outerWidth(tableWidth);
      $fixedTableHeader.outerWidth(tableWidth);

      // 重新插入渲染队列，使表格按上面宽度设置渲染
      setTimeout(() => {
        let tableWidth = 0;
        const widths = [];

        // 收集重新渲染后的实际列宽度
        $ths.each(function () {
          const width = $(this).outerWidth();
          widths.push(width);
          tableWidth += width;
        });

        // 设置表格宽度，如果表格宽度小于表格可见区域宽度，
        // 以可见区域宽度为准
        if (tableWidth < this.tableWidth) tableWidth = this.tableWidth;
        this.setState({ tableWidth });
        $table.outerWidth(tableWidth);
        $fixedTableHeader.outerWidth(tableWidth);

        // 由于上面第一步设置的列宽度在渲染后会出现细微偏差，
        // 所以在这里用新收集的实际宽度给列设置最终实际宽度
        widths.forEach((width, index) => {
          $ths.eq(index).outerWidth(width);
          $fixedHeaderThs.eq(index).outerWidth(width);
          if (freezeColumn) {
            $fixedAsideThs.eq(index).outerWidth(width);
            $fixedHeaderAsideThs.eq(index).outerWidth(width);
          }
        });

        this.widths = widths;
      }, 0);
    }, 0);
  }

  ccolCount = -1;

  rowIndex = -1;

  drill = id => {
    const { options } = this.state;
    this.setState({
      options: {
        ...options,
        data: this.drillHelper(options.data, id),
      },
    });
  }

  drillHelper(data, id) {
    const { autoExpand } = this.props;
    return data.map(row => {
      if (row.id !== id) {
        if (row.children) {
          return {
            ...row,
            children: this.drillHelper(row.children, id),
          };
        }
        return row;
      }
      return {
        ...row,
        expanded: (autoExpand && row.expanded === undefined) ? false : !row.expanded,
      };
    });
  }

  render() {
    const {
      options,
      loading,
      page,
      hasMorePage,
      tableWidth,
    } = this.state;
    const {
      className,
      style = {},
      freezeHeader,
      freezeColumn,
      scrollY,
      pagination,
    } = this.props;
    const { height } = style;
    const { columns, data = [] } = options;
    const visibleColumns = this.getVisibleTbodyColumns(columns);
    const arrayMode = visibleColumns.length > 0 && !visibleColumns[0].key;
    let tips;
    if (loading) {
      tips = <div className="table-loading">加载中...</div>;
    } else if (data.length === 0) {
      tips = '暂无数据...';
    }

    const header = this.getTableHeader(this.getVisibleHeads());
    const fixedHeaderAside = this.getFreezeHeaderAside(this.getVisibleHeads());

    return (
      <div
        className={`
          table-wrapper ${className || ''}
          ${scrollY ? 'scroll-y' : ''}
        `}
        style={{
          ...style,
          height: !_.isBoolean(scrollY) ? `${scrollY}px !important` : '',
        }}
        ref={ref => { this.refTableWrapper = ref; }}
      >
        <div
          className="table-scroller scrollbar-inner"
          ref={ref => { this.refDataTableScroller = ref; }}
        >
          <table
            className="table"
            ref={ref => { this.refDataTable = ref; }}
          >
            {header}
            <tbody>
              {this.getTbody(data, visibleColumns, arrayMode, null, 0, true)}
            </tbody>
          </table>
          {pagination &&
            <div
              style={{ width: tableWidth }}
              className={`pagination ${hasMorePage ? 'has-more-page' : ''}`}
              onClick={() => {
                if (!hasMorePage) return;
                const p = page + 1;
                pagination(p);
                this.setState({ page: p });
              }}
            >
              <div style={{ width: this.tableWidth }} ref={ref => { this.refHasMoreButton = ref; }}>
                {hasMorePage ? '加载更多...' : '暂无更多数据'}
              </div>
            </div>
          }
        </div>
        {freezeHeader &&
          <div
            className="fixed-table-header-scroller"
            ref={ref => { this.refFixedTableHeaderScroller = ref; }}
          >
            <table
              className="table"
              ref={ref => { this.refFixedTableHeader = ref; }}
            >
              {header}
            </table>
          </div>
        }
        {freezeColumn &&
          [<div
            key={1}
            className="fixed-table-aside-scroller"
            ref={ref => { this.refFixedTableAsideScroller = ref; }}
          >
            <table
              className="table"
              ref={ref => { this.refFixedTableAside = ref; }}
            >
              {fixedHeaderAside}
              <tbody>
                {this.getTbody(data, visibleColumns, arrayMode, freezeColumn, 0, true)}
              </tbody>
            </table>
            {pagination && <div className="pagination-placeholder" />}
          </div>,
          <div
            key={2}
            className="fixed-table-header-aside-scroller"
          >
            <table
              className="table"
              ref={ref => { this.refFixedTableHeaderAside = ref; }}
            >
              {fixedHeaderAside}
            </table>
          </div>]
        }
        {tips && <TableTips style={{ height }}>{tips}</TableTips>}
      </div>
    );
  }
}

export default Table;
