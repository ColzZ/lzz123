import React, { Component, PropTypes } from 'react';
import './style';
import TabContent from '../TabContent';

export default class Tabs extends Component {
  static propTypes = {
    children: PropTypes.node.isRequired,
    className: PropTypes.string,
    style: PropTypes.object,
    defaultActiveKey: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
    activeKey: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
    onSelect: PropTypes.func,
  }

  constructor(props) {
    super(props);
    this.state = {
      defaultActiveKey: props.defaultActiveKey,
    };
  }

  componentWillReceiveProps({ defaultActiveKey }) {
    if (this.props.defaultActiveKey !== defaultActiveKey) {
      this.setState({ defaultActiveKey });
    }
  }

  getDefaultActiveKey(children) {
    let defaultActiveKey;

    if (React.Children.count(children) === 0) {
      return -1;
    }

    React.Children.forEach(children, child => {
      if (defaultActiveKey == null) {
        defaultActiveKey = child.props.eventKey;
      }
    });

    return defaultActiveKey;
  }

  render() {
    const { children, className, style, activeKey, onSelect } = this.props;
    const { defaultActiveKey } = this.state;
    const hasDefaultActiveKey = typeof defaultActiveKey !== 'undefined';
    const actKey = hasDefaultActiveKey ?
      defaultActiveKey :
      activeKey || this.getDefaultActiveKey(children);

    return (
      <div
        className={`tabs ${className || ''}`}
        style={style}
      >
        <ul className="nav">
          {React.Children.map(children, ({ props: { eventKey, title } }) => (
            <li
              key={eventKey}
              className={actKey === eventKey ? 'active' : ''}
              onClick={() => {
                if (hasDefaultActiveKey) {
                  this.setState({ defaultActiveKey: eventKey });
                }
                if (onSelect) {
                  onSelect(eventKey);
                }
              }}
            >
              <a>{title}</a>
            </li>
          ))}
        </ul>
        <TabContent activeKey={actKey}>
          {children}
        </TabContent>
      </div>
    );
  }
}
