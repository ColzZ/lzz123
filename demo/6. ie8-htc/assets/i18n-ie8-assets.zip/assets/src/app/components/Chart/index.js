import React, { Component, PropTypes } from 'react';
import echarts from 'echarts';

export default class Chart extends Component {
  static propTypes = {
    options: PropTypes.object.isRequired,
    style: PropTypes.object,
    height: PropTypes.number,
    width: PropTypes.number,
    onReady: PropTypes.func,
  }

  static defaultProps = {
    height: 400,
  };

  componentDidMount() {
    this.drawChart();
  }

  shouldComponentUpdate(nextProps) {
    return this.props.options !== nextProps.options;
  }

  componentDidUpdate(prevProps) {
    if (this.props.options && (prevProps.options !== this.props.options)) {
      this.drawChart();
    }
  }

  componentWillUnmount() {
    this.chart.dispose();
  }

  drawChart() {
    const { options, onReady } = this.props;

    this.chart = echarts.init(this.refChart);
    this.chart.clear();
    this.chart.setOption(options);

    if (onReady) {
      onReady(this.chart);
    }
  }

  render() {
    const { width, height, style, ...props } = this.props;

    return (
      <div
        ref={ref => { this.refChart = ref; }}
        style={{
          height,
          width,
          ...style,
        }}
        {...props}
      />
    );
  }
}
