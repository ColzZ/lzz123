import React from 'react';
import './style';
import DropdownPanel from '../DropdownPanel';
import DropdownMenu from '../DropdownMenu';

export default class Popover extends DropdownMenu {
  render() {
    const { open } = this.state;
    const {
      children,
      className = '',
      style,
      menuStyle,
      target,
      disabled,
      multiple,
      // onClick,
      loading,
      show,
    } = this.props;

    return (
      <div
        className={[
          'dropdown popover',
          show || open ? 'open' : '',
          className,
          disabled ? 'disabled' : '',
        ].join(' ')}
        style={style}
        ref={ref => { this.refDropdown = ref; }}
        onMouseEnter={this.handleOpen}
        onMouseLeave={this.handleClose}
      >
        {target && <div onClick={this.handleOpen}>{target}</div>}
        <div className={`dropdown-menu ${multiple ? 'multiple' : 'no-multiple'}`} style={menuStyle}>
          {loading &&
            <div className="loading-box">
              <div className="loading-icon" />
            </div>
          }
          {(() => {
            if (children) {
              return children;
            } else if (multiple) {
              return (
                <DropdownPanel
                  onSubmit={this.handleMultipleSubmit}
                >
                  {this.renderDropdownMenu()}
                </DropdownPanel>
              );
            }
            return this.renderDropdownMenu();
          })()}
        </div>
      </div>
    );
  }
}
