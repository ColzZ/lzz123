import React, { PropTypes } from 'react';
import './style';

const Toolbar = ({
  style = {},
  className = '',
  children,
  color = '',
  title,
  noBorderBottom,
}) => (
  <div
    className={`toolbar ${className} ${color} ${noBorderBottom ? 'no-border-bottom' : ''}`}
    style={style}
  >
    {title && <h2>{title}</h2>}
    {children}
  </div>
);

Toolbar.propTypes = {
  style: PropTypes.object,
  className: PropTypes.string,
  children: PropTypes.node.isRequired,
  color: PropTypes.string,
  title: PropTypes.string,
  noBorderBottom: PropTypes.bool,
};

export default Toolbar;
