import React, { PropTypes, Component } from 'react';

export default class Td extends Component {
  static propTypes = {
    className: PropTypes.string,
    style: PropTypes.object,
    data: PropTypes.any.isRequired,
    render: PropTypes.func,
    rowData: PropTypes.object.isRequired,
    coordinate: PropTypes.object.isRequired,
    drillPoint: PropTypes.bool,
    autoExpand: PropTypes.bool,
    onDrill: PropTypes.func.isRequired,
    expanded: PropTypes.bool,
    drillLevel: PropTypes.number,
  }

  constructor(props) {
    super(props);
    this.state = {};
  }

  render() {
    const { className = '', style = {}, data, render, rowData, coordinate, drillPoint, autoExpand, onDrill, expanded, drillLevel } = this.props;

    let visibleData = typeof data === 'object' && data.data ? data.data : data;
    visibleData = visibleData || data;

    let drill;
    if (drillPoint) {
      let drillClassName = '';
      if (rowData.children) {
        drillClassName = (autoExpand && expanded === undefined) || expanded ? 'drilled' : '';
      } else {
        drillClassName = 'no-chidlren';
      }
      drill = (
        <div
          className={`drill-point ${drillClassName}`}
          style={{ marginLeft: drillLevel * 20 }}
          onClick={() => onDrill(rowData.id)}
        />
      );
    }

    return (
      <td
        style={style}
        className={`${className} ${data.className || ''}`}
        ref={ref => { this.refTd = ref; }}
        rowSpan={data.rowSpan}
        colSpan={data.colSpan}
        onClick={data.onClick}
      >
        {drill}
        {!render ?
          visibleData :
          render(visibleData, 'display', rowData, coordinate, this.refTd)
        }
      </td>
    );
  }
}
