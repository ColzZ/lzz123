// Action prefix
const ACTION_PREFIX = module.id;

// Actions const
export const LOAD_DATE_OPTIONS_SUCCESS = `${ACTION_PREFIX}/LOAD_DATE_OPTIONS_SUCCESS`;
export const LOAD_CITY_OPTIONS_SUCCESS = `${ACTION_PREFIX}/LOAD_CITY_OPTIONS_SUCCESS`;
export const LOAD_BODY_OPTIONS_SUCCESS = `${ACTION_PREFIX}/LOAD_BODY_OPTIONS_SUCCESS`;
export const LOAD_MANF_BRAND_OPTIONS_SUCCESS = `${ACTION_PREFIX}/LOAD_MANF_BRAND_OPTIONS_SUCCESS`;
export const LOAD_MODEL_OPTIONS_SUCCESS = `${ACTION_PREFIX}/LOAD_MODEL_OPTIONS_SUCCESS`;
export const LOAD_VERSION_OPTIONS_SUCCESS = `${ACTION_PREFIX}/LOAD_VERSION_OPTIONS_SUCCESS`;
export const RESTORE_VERSION_OPTIONS = `${ACTION_PREFIX}/RESTORE_VERSION_OPTIONS`;
export const LOAD_COMMON_OBJECT_OPTIONS_SUCCESS = `${ACTION_PREFIX}/LOAD_COMMON_OBJECT_OPTIONS_SUCCESS`;
export const RESTORE_COMMON_OBJECT_OPTIONS = `${ACTION_PREFIX}/RESTORE_COMMON_OBJECT_OPTIONS`;
export const LOAD_TABLE_OPTIONS_SUCCESS = `${ACTION_PREFIX}/LOAD_TABLE_OPTIONS_SUCCESS`;

// Actions

export const loadDateOptions = () => ({
  type: [LOAD_DATE_OPTIONS_SUCCESS],
  // endpoint: `${window.$ctx}/assets/static/data/date-months.json`,
  endpoint: `${window.$ctx}/price/cityTpSelect/getCityTpSelectInitDate.do`,
});

export const loadCityOptions = () => ({
  type: [LOAD_CITY_OPTIONS_SUCCESS],
  // endpoint: `${window.$ctx}/assets/static/data/cities-group-by-area.json`,
  endpoint: `${window.$ctx}/commonNew/getCityListInfo.do`,
});

export const loadBodyOptions = () => ({
  type: [LOAD_BODY_OPTIONS_SUCCESS],
  // endpoint: `${window.$ctx}/assets/static/data/body.json`,
  endpoint: `${window.$ctx}/commonNew/getSubModelBodyTypeListInfo.do`,
});

export const loadManfBrandOptions = data => ({
  type: [LOAD_MANF_BRAND_OPTIONS_SUCCESS],
  endpoint: {
    // url: `${window.$ctx}/assets/static/data/manf-brands.json`,
    url: `${window.$ctx}/price/CityTpSelectCommon/getManfBrandListInfo.do`,
    data,
  },
});

export const loadModelOptions = data => ({
  type: [LOAD_MODEL_OPTIONS_SUCCESS],
  endpoint: {
    // url: `${window.$ctx}/assets/static/data/models.json`,
    url: `${window.$ctx}/price/CityTpSelectCommon/getrSubModelListInfo.do`,
    data,
  },
});

export const loadVersionOptions = data => ({
  type: [LOAD_VERSION_OPTIONS_SUCCESS],
  endpoint: {
    // url: `${window.$ctx}/assets/static/data/versions.json`,
    url: `${window.$ctx}/price/CityTpSelectCommon/getVersionsDataListInfo.do`,
    data,
  },
});

export const restoreVersionOptions = () => ({
  type: RESTORE_VERSION_OPTIONS,
});

export const loadCommonObjectOptions = data => ({
  type: [LOAD_COMMON_OBJECT_OPTIONS_SUCCESS],
  endpoint: {
    // url: `${window.$ctx}/assets/static/data/common-objects.json`,
    url: `${window.$ctx}/commonNew/getCustomGroupVersionListInfo.do`,
    data,
  },
});

export const restoreObjectOptions = () => ({
  type: RESTORE_COMMON_OBJECT_OPTIONS,
});

export const loadTableOptions = (data, selectedCityOptions, page, analysisType) => ({
  type: [LOAD_TABLE_OPTIONS_SUCCESS],
  endpoint: {
    // url: `${window.$ctx}/assets/static/data/tp-search/table.json`,
    url: page ? `${window.$ctx}/price/cityTpSelect/getHasMoreTpData.do` :
                `${window.$ctx}/price/cityTpSelect/getTpData.do`,
    data,
  },
  selectedCityOptions,
  page,
  analysisType,
});
