import { stringify, parse } from 'querystring';
import $ from 'jquery';
import React, { Component, PropTypes } from 'react';

import './style';
import DropdownMenu from '../../../../components/DropdownMenu';

export default class Header extends Component {
  static propTypes = {
    pathname: PropTypes.string.isRequired,
  }

  static contextTypes = {
    router: PropTypes.object,
  }

  static languageOptions = [
    { value: 'zh_CN', text: '简体中文', selected: true },
    { value: 'en', text: 'English' },
  ]

  constructor(props) {
    super(props);
    this.state = {
      languageOptions: [],
    };
  }

  componentWillMount() {
    const language = $('html').attr('lang');
    const languageOptions = Header.languageOptions.map(option => ({
      ...option,
      selected: option.value === language,
    }));
    this.setState({ languageOptions });
  }

  select = language => {
    const { pathname: hashPathname } = this.props;
    const { protocol, host, pathname, search } = window.location;
    const queryObject = parse(search.replace(/^\?/, ''));
    queryObject.language = language;
    const href = `${protocol}//${host}${pathname}?${stringify(queryObject)}#${hashPathname}`;
    window.location.href = href;
  }

  render() {
    return (
      <div className="page-header">
        <div
          className="logo"
        />
        <div className="user-menu">
          <span className="user-name">{__('welcome')}，{window.$initialData.userName}</span>
          <a href={`${window.$ctx}/common/logout.jsp`}>{__('backToHome')}</a>
          <DropdownMenu
            hasSelected={false}
            options={this.state.languageOptions}
            onSelect={this.select}
          />
        </div>
      </div>
    );
  }
}
