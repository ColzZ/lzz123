import createReducer from 'createReducer';

// Actions Const

const ACTION_PREFIX = module.id;
export const TOGGLE = `${ACTION_PREFIX}/TOGGLE_PAGE_ASIDE`;

// Action Creators

export const toggle = () => ({
  type: TOGGLE,
});

// Reducer

export default createReducer({
  CONSTRUCT() {
    return true;
  },

  [TOGGLE](state) {
    return !state;
  },
});
