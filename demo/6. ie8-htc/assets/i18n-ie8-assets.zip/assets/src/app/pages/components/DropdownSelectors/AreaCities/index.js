import _ from 'lodash';
import React from 'react';

import GroupListSelector from '../../../../components/DropdownSelector/Selectors/GroupList';
import AreaCitiesContent from './Content';

export default class AreaCities extends GroupListSelector {
  placeholder = '选择城市'

  selectedText = '已选城市'

  /**
   * 获取全部已选项并平面化，便于其它操作统计结果
   * @param  {array} options 被操作的选项数组
   * @return {array}         已过滤已选项并平面化后的选项结果数组
   */
  getSelectedOptions = options => {
    const checkOptions = _.flatten(options.map(group => group.list)).filter(item => item.checked);
    if (checkOptions.length > 0) {
      return checkOptions;
    }
    return [{ id: '-1', text: '全国均价', checked: true }];
  }

  getContent() {
    const { multiple } = this.props;
    const { options } = this.state;
    return (
      <AreaCitiesContent
        options={options}
        multiple={multiple}
        onSelect={this.select}
      />
    );
  }
}
