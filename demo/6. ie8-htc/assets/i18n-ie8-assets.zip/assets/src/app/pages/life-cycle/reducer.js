import createReducer from 'createReducer';

import {
  LC_ACTION,
} from './actions';

export default createReducer({
  CONSTRUCT() {
    return {
      dd: 1,
    };
  },

  [LC_ACTION](state, { response }) {
    return { ...state, response };
  },
});
