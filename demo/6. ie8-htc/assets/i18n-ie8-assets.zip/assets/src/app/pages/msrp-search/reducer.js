import createReducer from 'createReducer';

import {
  LOAD_DATE_OPTIONS_SUCCESS,
  LOAD_BODY_OPTIONS_SUCCESS,
  LOAD_MODEL_OPTIONS_SUCCESS,
  LOAD_TABLE_OPTIONS_SUCCESS,
} from './actions';

const initColumns = [
  [
    { key: 'date', title: '年月', className: 'text-center' },
    { key: 'versionCode', title: '型号编码', enTitle: 'versionCode', className: 'text-center' },
    { key: 'segment', title: '级别', className: 'text-center' },
    { key: 'oem', title: '生产厂商', className: 'text-center' },
    { key: 'model', title: '车型', className: 'text-center' },
    { key: 'engineCapacity', title: '排量', className: 'text-center' },
    { key: 'transmissionType', title: '排档方式', className: 'text-center' },
    { key: 'versionMark', title: '型号标识', className: 'text-center' },
    { key: 'bodyType', title: '车身形式', className: 'text-center' },
    { key: 'launchDate', title: '上市日期', className: 'text-center' },
    { key: 'year', title: '年款', className: 'text-center' },
    { key: 'msrp', title: '厂商指导价(元)', className: 'text-center' },
  ],
  [
    { key: 'versionCode', title: '型号编码', enTitle: 'versionCode', className: 'text-center', rowSpan: 2 },
    { key: 'segment', title: '级别', className: 'text-center', rowSpan: 2 },
    { key: 'oem', title: '生产厂商', className: 'text-center', rowSpan: 2 },
    { key: 'model', title: '车型', className: 'text-center', rowSpan: 2 },
    { key: 'engineCapacity', title: '排量', className: 'text-center', rowSpan: 2 },
    { key: 'transmissionType', title: '排档方式', className: 'text-center', rowSpan: 2 },
    { key: 'versionMark', title: '型号标识', className: 'text-center', rowSpan: 2 },
    { key: 'bodyType', title: '车身形式', className: 'text-center', rowSpan: 2 },
    { key: 'launchDate', title: '上市日期', className: 'text-center', rowSpan: 2 },
    { key: 'year', title: '年款', className: 'text-center', rowSpan: 2 },
    {
      title: '厂商指导价(元)',
      children: [
        { key: 'month201703', title: '201703', className: 'text-center' },
        { key: 'month201704', title: '201704', className: 'text-center' },
      ],
    },
  ],
];

export default createReducer({
  CONSTRUCT() {
    return {
      dateOptions: [{}, {}],
      bodyOptions: [],
      modelOptions: [[], [], [], []],
      tableOptions: {
        columns: [],
        data: [],
      },
    };
  },

  [LOAD_DATE_OPTIONS_SUCCESS](state, { response: { data } }) {
    return { ...state, dateOptions: data };
  },

  [LOAD_BODY_OPTIONS_SUCCESS](state, { response: { data } }) {
    return { ...state, bodyOptions: data };
  },

  [LOAD_MODEL_OPTIONS_SUCCESS](state, { response: { data } }) {
    return { ...state, modelOptions: data };
  },

  [LOAD_TABLE_OPTIONS_SUCCESS](state, {
    response: { data },
    analysisType,
    startTime,
    endTime,
    page,
  }) {
    const columns = initColumns[analysisType - 1];

    if (analysisType === 2) {
      let [startYear, startMonth] = startTime.split('-');
      let [endYear, endMonth] = endTime.split('-');
      startYear -= 0;
      startMonth -= 0;
      endYear -= 0;
      endMonth -= 0;

      const months = [];
      if (startYear < endYear) {
        for (let i = startMonth; i <= 12; i += 1) {
          months.push(`${startYear}${i < 10 ? '0' : ''}${i}`);
        }
        for (let i = startYear + 1; i < endYear; i += 1) {
          for (let j = 1; j < 13; j += 1) {
            months.push(`${i}${j < 10 ? '0' : ''}${j}`);
          }
        }
        for (let i = 1; i <= endMonth; i += 1) {
          months.push(`${endYear}${i < 10 ? '0' : ''}${i}`);
        }
      } else if (startYear === endYear) {
        for (let i = startMonth; i <= endMonth; i += 1) {
          months.push(`${endYear}${i < 10 ? '0' : ''}${i}`);
        }
      }
      const lastColumn = columns[columns.length - 1];
      lastColumn.colSpan = months.length;
      lastColumn.children = months.map(month => (
        { key: month, title: month, className: 'text-center' }
      ));
    }

    const nextData = page ? state.tableOptions.data.concat(data) : data;

    return { ...state, tableOptions: { ...state.tableOptions, columns, data: nextData } };
  },
});
