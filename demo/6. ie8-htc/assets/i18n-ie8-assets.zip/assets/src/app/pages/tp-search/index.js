import { connect } from 'react-redux';

import {
  loadDateOptions,
  loadCityOptions,
  loadBodyOptions,
  loadManfBrandOptions,
  loadModelOptions,
  loadVersionOptions,
  restoreVersionOptions,
  loadCommonObjectOptions,
  restoreObjectOptions,
  loadTableOptions,
} from './actions';

import TpSearch from './components/TpSearch';

export default connect(
  state => state.tpSearch,
  {
    loadDateOptions,
    loadCityOptions,
    loadBodyOptions,
    loadManfBrandOptions,
    loadModelOptions,
    loadVersionOptions,
    restoreVersionOptions,
    loadCommonObjectOptions,
    restoreObjectOptions,
    loadTableOptions,
  }
)(TpSearch);
