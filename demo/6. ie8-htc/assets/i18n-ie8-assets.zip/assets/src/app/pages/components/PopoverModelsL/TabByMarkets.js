import TabContentSuper from './TabContentSuper';

export default class TabByMarkets extends TabContentSuper {
  hasFastGo = true

  fastGoType = 'select'

  // filter(options, showMain) {
  //   if (!showMain) return options;
  //   return options.map(group => {
  //     const list = group.list.map(subGroup => {
  //       const list = subGroup.list.filter(model => model.isMain);
  //       const nextSubGroup = {
  //         ...subGroup,
  //         list,
  //       };
  //       return list.length > 0 ? nextSubGroup : false;
  //     }).filter(subGroup => subGroup);
  //     const nextGroup = {
  //       ...group,
  //       list,
  //     };
  //     return list.length > 0 ? nextGroup : false;
  //   }).filter(group => group);
  // }

  handleCheckAll(checked) {
    const { options, updateOptions } = this.props;
    updateOptions(options.map(tab => (
      tab.map(group => this.checkAllChildren(group, checked))
    )));
  }

  render() {
    return super.render(0);
  }
}
