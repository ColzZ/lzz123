import $ from 'jquery';
import React, { Component, PropTypes } from 'react';

import 'jquery.scrollbar';
import './style';

export default class Scrollbar extends Component {
  static propTypes = {
    children: PropTypes.node.isRequired,
    className: PropTypes.string,
  }

  componentDidMount() {
    $(this.refScrollbar).scrollbar();
  }

  render() {
    const { children, className = '' } = this.props;

    return (
      <div
        className={`dropdown-selector-scrollbar scrollbar-inner ${className}`}
        ref={ref => { this.refScrollbar = ref; }}
      >
        {children}
      </div>
    );
  }
}
