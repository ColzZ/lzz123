import _ from 'lodash';
import React, { PropTypes } from 'react';

import SelectorTable from './selectoTable';
import Option from '../../../../components/DropdownSelector/PopoverContent/Option';
import PopoverContent from './PopverContent'; // 继承自

export default class GroupListPopoverContent extends PopoverContent {
  static propTypes = {
    onSelect: PropTypes.func.isRequired,
    className: PropTypes.string,
    options: PropTypes.array.isRequired,
  }

  static getCheckedAll(options) {
    return _.flatten(options.map(group => group.list)).every(model => model.checked);
  }

  static checkAllOptions = (options, checked) => {
    if (!options) return options;

    return options.map(group => ({
      ...group,
      checked,
      list: group.list.map(model => ({
        ...model,
        checked,
      })),
    }));
  }

  static getSelectedOptions = options => {
    if (!options) return [];

    return _.flatten(options.map(group => group.list)).filter(item => item.checked);
  }

  // 单选按钮点击触发的方法
  checkGroup = value => this.props.options.map(group => {
    if (group.id === value) {
      const checked = !group.checked;
      return {
        ...group,
        checked,
      };
    }
    return group;
  })

  checkOption = value => {
    const { multiple } = this.props;
    return this.props.options.map(group => {
      const list = group.list.map(item => {
        if (multiple) {
          if (item.id === value) {
            return {
              ...item,
              checked: !item.checked,
            };
          }
          return item;
        }
        return {
          ...item,
          checked: item.id === value,
        };
      });
      return {
        ...group,
        checked: list.every(item => item.checked),
        list,
      };
    });
  }

  // 生成body | onClick ==> this.checkGroup
  getOption = (props, onClick) => (
    <Option
      {...props}
      // key={props.id}
      className="oA-L"
      onClick={value => {
        let options;
        if (onClick) {
          options = onClick(value);
        } else {
          options = this.checkOption(value);
        }
        this.props.onSelect(options);
      }}
    />
  )

  render() {
    const { className, options, multiple } = this.props;
    return (
      <SelectorTable className={className}>
        <div>
          {options.map((group, index) => (
            <div key={group.id || index} className="oDiv-L">
              {multiple && group.id ? this.getOption(group, this.checkGroup) : <div className="text-center">{group.text}</div>}
            </div>
          ))}
        </div>
      </SelectorTable>
    );
  }
}
