import _ from 'lodash';
import React, { PropTypes } from 'react';

import './style';
import GroupList from '../../../../components/DropdownSelector/PopoverContent/GroupList';
import RadioGroup from '../../../../components/RadioGroup';

export default class AreaCitiesContent extends GroupList {
  static propTypes = {
    className: PropTypes.string,
  }

  constructor(props) {
    super(props);
    this.state = {
      fastSelect: 1,
      fastSelectOptions: [
        { value: 1, text: '全国均价', checked: true },
        { value: 2, text: '全选城市' },
      ],
    };
  }

  componentWillUpdate(nextProps, nextState) {
    if (this.state.fastSelect !== nextState.fastSelect && nextState.fastSelect > 0) {
      const checked = nextState.fastSelect === 2;
      const options = nextProps.options.map(group => ({
        ...group,
        checked,
        list: group.list.map(item => ({
          ...item,
          checked,
        })),
      }));
      this.props.onSelect(options);
    }

    if (this.props.options !== nextProps.options) {
      const selectedAllOptions = nextProps.options.every(group => group.checked);
      const hasSelectedOptions = !!_.flatten(nextProps.options.map(group => group.list))
        .find(group => group.checked);
      let fastSelectOptions;

      // 全选城市时，选择全选按钮
      if (selectedAllOptions) {
        fastSelectOptions = nextState.fastSelectOptions.map(option => ({
          ...option,
          checked: option.value === 2,
        }));
      // 部分选择城市时，反选全国、全选按钮
      } else if (hasSelectedOptions) {
        fastSelectOptions = nextState.fastSelectOptions.map(option => ({
          ...option,
          checked: false,
        }));
        this.setState({ fastSelect: 0 });
      // 全部城市不选时，选择全国按钮
      } else {
        fastSelectOptions = nextState.fastSelectOptions.map(option => ({
          ...option,
          checked: option.value === 1,
        }));
      }
      this.setState({ fastSelectOptions });
    }
  }

  render() {
    const { className = '' } = this.props;

    return (
      <div className={`dropdown-selector-area-cities ${className}`}>
        <RadioGroup
          className="fast-select"
          options={this.state.fastSelectOptions}
          onSelect={fastSelect => this.setState({ fastSelect })}
        />
        {super.render()}
      </div>
    );
  }
}
