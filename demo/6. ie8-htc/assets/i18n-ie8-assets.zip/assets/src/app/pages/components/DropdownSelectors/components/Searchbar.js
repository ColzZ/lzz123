import React, { Component, PropTypes } from 'react';

export default class Searchbar extends Component {
  static propTypes = {
    onChange: PropTypes.func.isRequired,
  }

  constructor(props) {
    super(props);
    this.state = {
      keyword: '',
    };
  }

  render() {
    const { keyword } = this.state;
    const { onChange } = this.props;

    return (
      <input
        type="text"
        className="form-control pull-right"
        placeholder="查询..."
        value={keyword}
        onChange={event => {
          const keyword = event.target.value;
          this.setState({ keyword });
          onChange(keyword);
        }}
      />
    );
  }
}
