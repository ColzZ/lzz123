import createReducer from 'createReducer';
import { TOGGLE_PAGE_ASIDE } from '../actions';

export default createReducer({
  CONSTRUCT() {
    return true;
  },

  [TOGGLE_PAGE_ASIDE](state) {
    return !state;
  },
});
