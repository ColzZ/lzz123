import React, { PropTypes } from 'react';
import './style';

const PopupMenuCheckAll = ({ checked, onClick }) => (
  <a
    className={`popup-menu-check-all checkbox-controller ${checked ? 'checked' : ''}`}
    onClick={() => onClick(checked)}
  >
    <span className="glyphicon tt-ok-sign" /> {__('newEP.selectAll')}
  </a>
);

PopupMenuCheckAll.propTypes = {
  checked: PropTypes.bool.isRequired,
  onClick: PropTypes.func.isRequired,
};

export default PopupMenuCheckAll;
