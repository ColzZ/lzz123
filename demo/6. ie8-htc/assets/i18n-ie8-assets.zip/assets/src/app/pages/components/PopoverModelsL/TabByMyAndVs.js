import _ from 'lodash';
import TabContentSuper from './TabContentSuper';

export default class TabByMyAndVs extends TabContentSuper {
  hasFastGo = true

  search(options, keyword) {
    return options.reduce((groups, group) => {
      if (!group.list) return groups;

      let subGroups = group.list.filter(item => item.text.indexOf(keyword) > -1);
      if (subGroups.length === 0) {
        subGroups = this.search(group.list, keyword);
      }

      if (subGroups.length > 0) {
        groups.push({
          ...group,
          list: subGroups,
        });
      }

      return groups;
    }, []);
  }

  handleCheckAll(checked) {
    const { options, updateOptions } = this.props;
    const mainManfs = options[0].map(group => this.checkAllChildren(group, checked));
    const mainManfIds = checked ?
      _.flatten(mainManfs.map(group => group.list)).map(manf => manf.id) : [];
    updateOptions([
      mainManfs,
      options[1].map(group => (
        {
          ...group,
          list: group.list.map(child => ({
            ...child,
            checked: checked ? mainManfIds.includes(child.id) : false,
          })),
        }
      )),
    ]);
  }

  render() {
    return super.render(0);
  }
}
