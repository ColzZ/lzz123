import $ from 'jquery';
import React, { Component, PropTypes } from 'react';
import { stringify } from 'querystring';
import 'loading';

import Toolbar from '../../../components/Toolbar';
import Form from '../../../components/Form';
import FormGroup from '../../../components/FormGroup';
import Button from '../../../components/Button';
import Table from '../../../components/Table';
import DownloadExcel from '../../../components/DownloadExcel';

import PopoverModels from '../../components/PopoverModels';

export default class MsrpSearch extends Component {
  static propTypes = {
    // Props
    dateOptions: PropTypes.array.isRequired,
    bodyOptions: PropTypes.array.isRequired,
    modelOptions: PropTypes.array.isRequired,
    tableOptions: PropTypes.object.isRequired,

    // Actions
    loadDateOptions: PropTypes.func.isRequired,
    loadBodyOptions: PropTypes.func.isRequired,
    loadModelOptions: PropTypes.func.isRequired,
    loadTableOptions: PropTypes.func.isRequired,
  }

  static analysisTypeOptions = [
    { value: 1, text: '最新指导价', checked: true },
    { value: 2, text: '历史指导价' },
  ]

  constructor(props) {
    super(props);
    this.state = {
      tableHeight: 0,
      startTime: '',
      endTime: '',
      analysisType: 1,
      bodyTypes: '',
      models: '',
    };
  }

  componentWillMount() {
    $('body').showLoading();
    this.setState({ tableHeight: $(window).height() - 179 });
    this.props.loadDateOptions();
    this.props.loadBodyOptions();
  }

  componentWillReceiveProps(nextProps) {
    const {
      dateOptions,
      modelOptions,
      tableOptions,
    } = nextProps;

    if (this.props.dateOptions !== dateOptions) {
      this.setState({
        startTime: dateOptions[0].select,
        endTime: dateOptions[1].select,
      });
    }

    if (this.props.modelOptions !== modelOptions) {
      const models = this.getSelectedModelIds(modelOptions);
      this.setState({ models });
      $('body').hideLoading();
    }

    if (this.props.tableOptions !== tableOptions) {
      $('body').hideLoading();
    }
  }

  componentWillUpdate(nextProps, nextState) {
    const {
      startTime,
      endTime,
      bodyTypes,
    } = nextState;

    if (
      (
        this.state.startTime !== startTime ||
        this.state.endTime !== endTime ||
        this.state.bodyTypes !== bodyTypes
      ) && startTime && endTime
    ) {
      this.props.loadModelOptions({ startTime, endTime, bodyTypes });
    }
  }

  componentDidUpdate(prevProps, prevState) {
    const { models } = this.state;

    // 初次加载页面时，默认加载一次表格数据
    if (!this.firstLoadTableOptions && prevState.models !== models && models) {
      this.search();
      this.firstLoadTableOptions = true;
    }
  }

  getSelectedModelIds(modelOptions) {
    return PopoverModels.findSelectedOptions(modelOptions)
      .map(model => model.id).join(',');
  }

  getParams(params = {}) {
    const {
      startTime,
      endTime,
      analysisType,
      bodyTypes,
      models,
    } = this.state;

    return {
      startTime,
      endTime,
      analysisType,
      bodyTypes,
      models,
      ...params,
    };
  }

  getQuerystringParams() {
    return stringify(this.getParams());
  }

  search = page => {
    $('body').showLoading();
    const { analysisType, startTime, endTime } = this.state;
    const params = this.getParams(page ? { page } : {});
    this.props.loadTableOptions(params, analysisType, startTime, endTime, page);
  }

  render() {
    const {
      tableHeight,
    } = this.state;
    const {
      dateOptions,
      bodyOptions,
      modelOptions,
      tableOptions,
    } = this.props;

    return (
      <div>
        <Toolbar color="white">
          <h2 className="mr-50">指导价查询</h2>
          <Form inline className="inline-block">
            <FormGroup
              className="mr-20"
              type="monthFrame"
              label=""
              options={dateOptions}
              onSelect={(startTime, endTime) => this.setState({ startTime, endTime })}
            />
            <FormGroup
              className="mr-20"
              type="buttonRadio"
              options={MsrpSearch.analysisTypeOptions}
              onSelect={analysisType => this.setState({ analysisType })}
            />
            <FormGroup
              multiple
              className="mr-20"
              type="select"
              label=""
              options={bodyOptions}
              onSelect={bodyTypes => this.setState({ bodyTypes })}
            />
            <FormGroup
              className="mr-20"
              label=""
            >
              <PopoverModels
                options={modelOptions}
                onSubmit={value => this.setState({ models: value.ids })}
              />
            </FormGroup>
            <Button className="btn-primary" style={{ width: 80 }} onClick={this.search}>查询</Button>
          </Form>
          <DownloadExcel href={`${window.$ctx}/price/msrpQuery/exportMsrpData.do?${this.getQuerystringParams()}`} className="pull-right" text="中文" />
          <DownloadExcel href={`${window.$ctx}/price/msrpQuery/exportMsrpData.do?${this.getQuerystringParams()}&language=en`} className="pull-right" text="英文" />
        </Toolbar>
        <div className="p-10">
          <Table
            options={tableOptions}
            scrollY={tableHeight}
            freezeHeader
            pagination={this.search}
            ppNumber={30}
          />
        </div>
      </div>
    );
  }
}
