const ACTION_PREFIX = module.id;
export const NEP_GET_DATE = `${ACTION_PREFIX}/NEP_GET_DATE`;
export const NEP_GET_CITY = `${ACTION_PREFIX}/NEP_GET_CITY`;
export const NEP_GET_MODEL = `${ACTION_PREFIX}/NEP_GET_MODEL`;
export const NEP_GSOHO_DATE = `${ACTION_PREFIX}/NEP_GSOHO_DATE`;
export const NEP_GET_LIST_OPTIONS = `${ACTION_PREFIX}/NEP_GET_LIST_OPTIONS`;
export const NEP_CLEAN = `${ACTION_PREFIX}/NEP_CLEAN`;

// 获取 时间 options
export const getDateOptions = data => ({
  type: [NEP_GET_DATE],
  endpoint: {
    url: `${window.$ctx}/searchDate.do`,
    data,
  },
});
// 获取 城市 options
export const getCityOptions = data => ({
  type: [NEP_GET_CITY],
  endpoint: {
    url: `${window.$ctx}/searchCity.do`,
    data,
  },
});
// 获取 车型 options
export const getModelOptions = data => ({
  type: [NEP_GET_MODEL],
  endpoint: {
    url: `${window.$ctx}/searchSubModel.do`,
    data,
  },
});
export const getShowOrHideOptions = data => ({
  type: [NEP_GSOHO_DATE],
  data,
});
export const getListOptions = data => ({
  type: [NEP_GET_LIST_OPTIONS],
  endpoint: {
    url: `${window.$ctx}/searchPassengerCarInfo.do`,
    // url: `${window.$ctx}/assets/static/data/cmco-one.json`,
    data,
  },
});
export const clean = () => ({
  type: [NEP_CLEAN],
});
/*
// 获取时间
export const getDateOptions = () => ({
  type: [NEP_DATE],
  endpoint: {
    url: `${window.$ctx}/searchOptionData.do`,
    // url: `${window.$ctx}/assets/static/data/date-month.json`,
  },
});
// 获取城市层级
export const getCityOptions = () => ({
  type: [NEP_GCO_DATE],
  endpoint: {
    url: `${window.$ctx}/assets/static/data/ne-city.json`,
  },
});
// 获取车型层级
export const getModulesOptions = () => ({
  type: [NEP_GMO_DATE],
  endpoint: {
    url: `${window.$ctx}/assets/static/data/ne-modules.json`,
  },
});
// 获取城市不层级
export const getOneLevelOptions = () => ({
  type: [NEP_GOLO_DATE],
  endpoint: {
    url: `${window.$ctx}/assets/static/data/ne-one-level.json`,
  },
});
*/

