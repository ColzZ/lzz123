import React, { Component, PropTypes } from 'react';

import Option from '../../../../components/DropdownSelector/PopoverContent/Option';

export default class PopoverContent extends Component {
  static propTypes = {
    onSelect: PropTypes.func.isRequired,
  }

  getOption = (props, onClick) => (
    <Option
      {...props}
      key={props.id}
      onClick={value => {
        let options;
        if (onClick) {
          options = onClick(value);
        } else {
          options = this.checkOption(value);
        }
        this.props.onSelect(options);
      }}
    />
  )
}
