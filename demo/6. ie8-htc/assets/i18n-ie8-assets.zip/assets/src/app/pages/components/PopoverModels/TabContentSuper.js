import _ from 'lodash';
import React, { Component, PropTypes } from 'react';

import ButtonGroup from '../../../components/ButtonGroup';
import SelectorTable from '../../../components/DropdownSelector/PopoverContent/SelectorTable';
import FastGo from '../DropdownSelectors/components/FastGo';
import Scrollbar from '../DropdownSelectors/components/Scrollbar';
import CheckAll from '../DropdownSelectors/components/CheckAll';

export default class TabContentSuper extends Component {
  static propTypes = {
    options: PropTypes.array.isRequired,
    updateOptions: PropTypes.func.isRequired,
    enableCheckAll: PropTypes.bool,
  }

  static checkChildren = (children, selectedId) => (
    children.map(child => {
      const { id, checked, list } = child;
      const nextChild = { ...child };
      if (id) nextChild.checked = id === selectedId ? !checked : checked;
      if (list) nextChild.list = TabContentSuper.checkChildren(list, selectedId);
      return nextChild;
    })
  );

  constructor(props) {
    super(props);

    this.state = {
      keyword: '',
      showMain: true,
      filterMainOptions: [
        { text: '主要车型', value: true, checked: true },
        { text: '全部车型', value: false },
      ],
    };
  }

  getAllChecked(optionsIndex) {
    const options = this.props.options[optionsIndex];
    const groups = _.flatten(options.map(({ list }) => list));
    const models = _.flatten(groups.map(({ list }) => list));
    const everyGroupsChecked = groups.every(({ checked }) => checked) || false;
    const everyModelsChecked = models.every(({ checked }) => checked) || false;

    if (optionsIndex === 0) {
      return everyGroupsChecked && everyModelsChecked;
    }
    return everyModelsChecked;
  }

  checkAllChildren(options, checked) {
    return {
      ...options,
      list: options.list.map(child => ({
        ...child,
        checked,
      })),
    };
  }

  createOption = (id, text, checked, isImport) => (
    id ? (
      <a
        key={id}
        onClick={() => this.handleCheck(id)}
        data-dropdown-option
        className={`dropdown-menu-selector-option checkbox-controller ${checked ? 'checked' : ''}`}
        style={{ color: isImport ? '#dd7928' : '' }}
      >
        <span className="glyphicon tt-ok-sign" /> {text}
      </a>
    ) : <span>{text}</span>
  )

  search(options, keyword) {
    return options.reduce((groups, group) => {
      const subGroups = group.list.reduce((subGroups, subGroup) => {
        const models = subGroup.list.filter(item => (
          item.text.toLowerCase().indexOf(keyword.toLowerCase()) > -1
        ));

        if (models.length > 0) {
          subGroups.push({
            ...subGroup,
            list: models,
          });
        }

        return subGroups;
      }, []);

      if (subGroups.length > 0) {
        groups.push({
          ...group,
          list: subGroups,
        });
      }

      return groups;
    }, []);
  }

  handleChangeKeyword = event => {
    this.setState({ keyword: event.target.value });
  }

  handleCheck = id => {
    const { options, updateOptions } = this.props;
    const nextOptions = options.map(tab => (TabContentSuper.checkChildren(tab, id)));
    updateOptions(nextOptions);
  }

  selectAllTabModels(ids, checked, myModelId = 0, otherOptions) {
    const { options, updateOptions } = this.props;

    const nextOptions = (otherOptions || options).map((tab, index) => {
      const rIds = [...ids];
      return tab.map(group => {
        // 如果无匹配选项，group 原样返回
        if (rIds.length === 0) return group;
        return {
          ...group,
          list: group.list.map(subGroup => {
            if (rIds.length === 0) return subGroup;
            if (index === 0) {
              if (myModelId > 0) {
                if (myModelId !== subGroup.id) {
                  return subGroup;
                }
                return {
                  ...subGroup,
                  checked,
                  list: subGroup.list.map(model => ({
                    ...model,
                    checked,
                  })),
                };
              }

              return {
                ...subGroup,
                checked: rIds.includes(subGroup.id) ? checked : subGroup.checked,
                list: subGroup.list.map(model => {
                  if (rIds.includes(model.id)) {
                    return {
                      ...model,
                      checked,
                    };
                  }
                  return model;
                }),
              };
            }
            return {
              ...subGroup,
              list: subGroup.list.map(model => {
                if (rIds.length === 0) return model;
                const selectedIndex = rIds.indexOf(model.id);
                if (myModelId > 0 && myModelId === model.id) {
                  return {
                    ...model,
                    checked,
                  };
                } else if (selectedIndex > -1) {
                  rIds.splice(selectedIndex, 1);
                  return {
                    ...model,
                    checked,
                  };
                }
                return model;
              }),
            };
          }),
        };
      });
    });

    updateOptions(nextOptions);
  }

  selectAllChildren(checked, list, myModelId) {
    const ids = list.filter(item => item.checked !== checked).map(item => item.id);
    this.selectAllTabModels(ids, checked, myModelId);
  }

  selectAllGroup(checked, list) {
    const ids = _.flatten(list.map(item => item.list))
      .filter(item => item.checked !== checked)
      .map(item => item.id);

    this.selectAllTabModels(ids, checked);
  }

  checkAll(checked, activeKey) {
    const { options, updateOptions } = this.props;

    if (activeKey === 0) {
      const nextOptions = options.map(tab => tab.map(group => ({
        ...group,
        list: group.list.map(subGroup => ({
          ...subGroup,
          list: subGroup.list.map(model => ({
            ...model,
            checked: false,
          })),
          checked: false,
        })),
      })));

      const ids = _.flatten(nextOptions[0][0].list.map(group => (
        [group.id, ...group.list.map(model => model.id)]
      )));
      this.selectAllTabModels(ids, checked, 0, nextOptions);
    } else {
      const nextOptions = options.map((tab, index) => tab.map(group => ({
        ...group,
        list: group.list.map(subGroup => ({
          ...subGroup,
          list: subGroup.list.map(model => ({
            ...model,
            checked,
          })),
          checked: index === 0 ? checked : subGroup.checked,
        })),
      })));

      updateOptions(nextOptions);
    }
  }

  renderFastGo(visibleList) {
    const fastGoOptions = visibleList.map(m => ({
      value: m.text,
      text: m.text,
    }));

    return (
      <FastGo
        options={fastGoOptions}
        scrollbar={this}
        type={this.fastGoType}
      />
    );
  }

  render(optionsIndex) {
    const { enableCheckAll } = this.props;
    const options = this.props.options[optionsIndex];
    const { keyword, filterMainOptions, showMain } = this.state;
    let visibleList = this.search(options, keyword);
    if (this.filter) visibleList = this.filter(visibleList, showMain);

    let checkAllButton;
    if (enableCheckAll) {
      const allChecked = this.getAllChecked(optionsIndex);
      checkAllButton = (
        <CheckAll
          checked={allChecked}
          onClick={() => this.checkAll(!allChecked, optionsIndex)}
        />
      );
    }

    return (
      <div>
        {checkAllButton}
        <div className="legend">
          车型国别：
          <span style={{ color: '#3774b5' }}>国产</span>
          <span style={{ color: '#dd7928' }}>进口</span>
        </div>
        <div className="tool-bar clearfix">
          <input
            type="text"
            className="form-control pull-right"
            placeholder="查询..."
            value={keyword}
            onChange={event => this.handleChangeKeyword(event)}
          />
          {this.filter &&
            <ButtonGroup
              className="mr-10"
              options={filterMainOptions}
              onSelect={showMain => this.setState({ showMain })}
            />
          }
          {this.hasFastGo && optionsIndex > 0 && this.renderFastGo(visibleList)}
        </div>
        <Scrollbar ref={ref => { this.refScrollbar = ref ? ref.refScrollbar : null; }}>
          {
            visibleList.map(({ text, list }, index) => (
              <div key={index}>
                <div className="group-title-bar" data-fast-go={text}>
                  {optionsIndex === 1 &&
                    <input
                      type="checkbox"
                      checked={list.every(group => group.list.every(m => m.checked))}
                      onChange={event => {
                        this.selectAllGroup(
                          event.target.checked,
                          list,
                        );
                      }}
                    />
                  }
                  {text}
                </div>
                <SelectorTable>
                  <tbody>
                    {
                      list.map((row, index2) => {
                        const {
                          id,
                          text,
                          checked,
                          isImport,
                          list: list2,
                        } = row;
                        return (
                          <tr key={id || index2}>
                            <td style={{ width: 160, paddingLeft: 10 }}>
                              <input
                                type="checkbox"
                                checked={
                                  ((optionsIndex === 0 && checked) || optionsIndex > 0) &&
                                  list2.every(m => m.checked)
                                }
                                onChange={event => {
                                  this.selectAllChildren(
                                    event.target.checked,
                                    list2,
                                    id,
                                  );
                                }}
                              />
                              {optionsIndex === 0 ?
                                this.createOption(id, text, checked, isImport) : text
                              }
                            </td>
                            <td>
                              {list2.map(({ id, text, checked, isImport }) => (
                                this.createOption(id, text, checked, isImport)
                              ))}
                            </td>
                          </tr>
                        );
                      })
                    }
                  </tbody>
                </SelectorTable>
              </div>
            ))
          }
        </Scrollbar>
      </div>
    );
  }
}
