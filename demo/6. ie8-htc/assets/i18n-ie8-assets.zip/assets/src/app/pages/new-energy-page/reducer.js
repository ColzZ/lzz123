import createReducer from 'createReducer';

import {
  NEP_GET_DATE,
  NEP_GET_CITY,
  NEP_GET_MODEL,
  NEP_GSOHO_DATE,
  NEP_GET_LIST_OPTIONS,
  NEP_CLEAN,
} from './actions';

function getSOH(data) {
  // 1,2,3,4,7,8,9,10,11,17,25,26,29,30,31,32,33,36,37,38
  if (data) {
    return [
      { value: 1, id: 1, text: __('newEP.v1'), checked: true },
      { value: 2, id: 2, text: __('newEP.v2'), checked: true },
      { value: 3, id: 3, text: __('newEP.v3'), checked: true },
      { value: 4, id: 4, text: __('newEP.v4'), checked: true },
      { value: 5, id: 5, text: __('newEP.v5'), checked: false },
      { value: 6, id: 6, text: __('newEP.v6'), checked: false },
      { value: 7, id: 7, text: __('newEP.v7'), checked: true },
      { value: 8, id: 8, text: __('newEP.v8'), checked: true },
      { value: 9, id: 9, text: __('newEP.v9'), checked: true },
      { value: 10, id: 10, text: __('newEP.v10'), checked: true },

      { value: 11, id: 11, text: __('newEP.v11'), checked: true },
      { value: 12, id: 12, text: __('newEP.v12'), checked: false },
      { value: 13, id: 13, text: __('newEP.v13'), checked: false },
      { value: 14, id: 14, text: __('newEP.v14'), checked: false },
      { value: 15, id: 15, text: __('newEP.v15'), checked: false },
      { value: 16, id: 16, text: __('newEP.v16'), checked: false },
      { value: 17, id: 17, text: __('newEP.v17'), checked: true },
      { value: 18, id: 18, text: __('newEP.v18'), checked: false },
      { value: 19, id: 19, text: __('newEP.v19'), checked: false },
      { value: 20, id: 20, text: __('newEP.v20'), checked: false },

      // 电池容量、累计全国销量（乘联会）、最新月全国销量（乘联会）、最新月全国MIX、上牌信息、免购置税幅度、上年累计分款型上险数、当年累计分款型上险数、国家补贴、地方补贴、
      // 电池容量、上牌信息、免购置税幅度、国家补贴、地方补贴、
      { value: 21, id: 21, text: __('newEP.v21'), checked: false },
      { value: 25, id: 25, text: __('newEP.v25'), checked: true },
      { value: 26, id: 26, text: __('newEP.v26'), checked: true },
      { value: 29, id: 29, text: __('newEP.v29'), checked: true },
      { value: 30, id: 30, text: __('newEP.v30'), checked: true },

      { value: 31, id: 31, text: __('newEP.v31'), checked: true },
      { value: 32, id: 32, text: __('newEP.v32'), checked: true },
      { value: 33, id: 33, text: __('newEP.v33'), checked: true },
      { value: 34, id: 34, text: __('newEP.v34'), checked: false },
      { value: 35, id: 35, text: __('newEP.v35'), checked: false },
      { value: 36, id: 36, text: __('newEP.v36'), checked: true },
      { value: 37, id: 37, text: __('newEP.v37'), checked: true },
      { value: 38, id: 38, text: __('newEP.v38'), checked: true },
      { value: 39, id: 39, text: __('newEP.v39'), checked: false },
    ];
  }
  return [
    // 日期、频次、型号编码、型号全称、是否在产、是否在销、细分市场、品牌、生产商、品牌属性、
    { value: 1, id: 1, text: __('newEP.v1'), checked: true },
    { value: 2, id: 2, text: __('newEP.v2'), checked: true },
    { value: 3, id: 3, text: __('newEP.v3'), checked: true },
    { value: 4, id: 4, text: __('newEP.v4'), checked: true },
    { value: 5, id: 5, text: __('newEP.v5'), checked: false },
    { value: 6, id: 6, text: __('newEP.v6'), checked: false },
    { value: 7, id: 7, text: __('newEP.v7'), checked: true },
    { value: 8, id: 8, text: __('newEP.v8'), checked: true },
    { value: 9, id: 9, text: __('newEP.v9'), checked: true },
    { value: 10, id: 10, text: __('newEP.v10'), checked: true },

    // 车型、车身形式、发动机、上市年款、上市日期、变速箱、燃料类型、油箱容积、工信部综合油耗、续航里程、
    { value: 11, id: 11, text: __('newEP.v11'), checked: true },
    { value: 12, id: 12, text: __('newEP.v12'), checked: false },
    { value: 13, id: 13, text: __('newEP.v13'), checked: false },
    { value: 14, id: 14, text: __('newEP.v14'), checked: false },
    { value: 15, id: 15, text: __('newEP.v15'), checked: false },
    { value: 16, id: 16, text: __('newEP.v16'), checked: false },
    { value: 17, id: 17, text: __('newEP.v17'), checked: true },
    { value: 18, id: 18, text: __('newEP.v18'), checked: false },
    { value: 19, id: 19, text: __('newEP.v19'), checked: false },
    { value: 20, id: 20, text: __('newEP.v20'), checked: false },

  // 日期、频次、型号编码、细分市场、品牌、生产商、品牌属性、车型、燃料类型、型号全称、上牌信息、免购置税幅度
  // 、国家补贴、地方补贴、充电桩费用、安装充电桩服务费用、指导价、成交价(含充电桩)、折扣（不含补贴）、优惠组成

  // 电池容量、累计全国销量（乘联会）、最新月全国销量（乘联会）、最新月全国MIX、上牌信息、免购置税幅度、上年累计分款型上险数、当年累计分款型上险数、国家补贴、地方补贴、
    { value: 21, id: 21, text: __('newEP.v21'), checked: false },
    { value: 22, id: 22, text: __('newEP.v22'), checked: false },
    { value: 23, id: 23, text: __('newEP.v23'), checked: false },
    { value: 24, id: 24, text: __('newEP.v24'), checked: false },
    { value: 25, id: 25, text: __('newEP.v25'), checked: true },
    { value: 26, id: 26, text: __('newEP.v26'), checked: true },
    { value: 27, id: 27, text: __('newEP.v27'), checked: false },
    { value: 28, id: 28, text: __('newEP.v28'), checked: false },
    { value: 29, id: 29, text: __('newEP.v29'), checked: true },
    { value: 30, id: 30, text: __('newEP.v30'), checked: true },

  // 充电桩费用、安装充电桩服务费用、指导价、进店指导价、成交价(不含充电桩)、成交价(含充电桩)、折扣（不含补贴）、优惠组成、一次性充电补贴
    { value: 31, id: 31, text: __('newEP.v31'), checked: true },
    { value: 32, id: 32, text: __('newEP.v32'), checked: true },
    { value: 33, id: 33, text: __('newEP.v33'), checked: true },
    { value: 34, id: 34, text: __('newEP.v34'), checked: false },
    { value: 35, id: 35, text: __('newEP.v35'), checked: false },
    { value: 36, id: 36, text: __('newEP.v36'), checked: true },
    { value: 37, id: 37, text: __('newEP.v37'), checked: true },
    { value: 38, id: 38, text: __('newEP.v38'), checked: true },
    { value: 39, id: 39, text: __('newEP.v39'), checked: false },
  ];
}

export default createReducer({
  CONSTRUCT() {
    return {
      // dataOptionsL: {},
      dateOptions: [{}, {}],
      cityOptions: [],
      modelOptions: [],
      showOrHide: [],
      listOptions: {},
    };
  },

  [NEP_GET_DATE](state, { response }) {
    return { ...state, dateOptions: [response[0], response[0]] };
  },
  [NEP_GET_CITY](state, { response }) {
    return { ...state, cityOptions: response };
  },
  [NEP_GET_MODEL](state, { response }) {
    const { segmentMarketList, brandList, fuleTypeList } = response;
    const modelOptions = [segmentMarketList, brandList, fuleTypeList];
    return { ...state, modelOptions };
  },
  [NEP_GSOHO_DATE](state, { data }) {
    return { ...state, showOrHide: getSOH(data) };
  },
  [NEP_GET_LIST_OPTIONS](state, { response }) {
    return { ...state, listOptions: response };
  },
  [NEP_CLEAN]() {
    return { dateOptions: {}, cityOptions: {}, modelOptions: {}, showOrHide: [], listOptions: {} };
  },
});
