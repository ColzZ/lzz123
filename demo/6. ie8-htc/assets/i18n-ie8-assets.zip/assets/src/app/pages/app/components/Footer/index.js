import React from 'react';
import './style';

export default () => (
  <div className="page-footer">
    © 2016 - 2018 {__('ways')} <a>{__('icp')}</a>
  </div>
);
