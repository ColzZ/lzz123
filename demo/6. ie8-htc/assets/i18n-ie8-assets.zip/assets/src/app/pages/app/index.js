import { connect } from 'react-redux';

import './styles';
import App from './containers/App';

function mapStateToProps({ routing, aside }) {
  const { pathname, query } = routing.locationBeforeTransitions;

  return {
    pathname,
    query,
    aside,
  };
}

export default connect(mapStateToProps)(App);
