export const TOGGLE_PAGE_ASIDE = 'TOGGLE_PAGE_ASIDE';

export const togglePageAside = () => ({
  type: TOGGLE_PAGE_ASIDE,
});
