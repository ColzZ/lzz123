import React, { Component, PropTypes } from 'react';
import { connect } from 'react-redux';
import Toolbar from '../../components/Toolbar';
import FormGroup from '../../components/FormGroup';
import {
  action,
} from './actions';
import './style';

class LifeCycle extends Component {
  static propTypes = {
    dd: PropTypes.func,
  }

  constructor(props) {
    super(props);
    this.state = {
      a: 123,
    };
  }
  render() {
    return (
      <div className="life-cycle">
        <div className="title-one">
          <h2>生命周期分析</h2>
        </div>
        <Toolbar>
          <FormGroup
            type="monthRange"
            options={[{ min: '2012-1', max: '2017-5', select: '2017-3' }, { min: '2012-1', max: '2017-5', select: '2017-3' }]}
            onSelect={(s, e) => console.log(s, e)}
          />
        </Toolbar>
      </div>
    );
  }
}

function mapStateToProps(state) {
  console.log(state);
  return {
    ...state,
  };
}

export default connect(mapStateToProps, {
  action,
})(LifeCycle);
