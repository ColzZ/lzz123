// Action prefix
const ACTION_PREFIX = module.id;

// Actions const
export const LOAD_DATE_OPTIONS_SUCCESS = `${ACTION_PREFIX}/LOAD_DATE_OPTIONS_SUCCESS`;
export const LOAD_BODY_OPTIONS_SUCCESS = `${ACTION_PREFIX}/LOAD_BODY_OPTIONS_SUCCESS`;
export const LOAD_MODEL_OPTIONS_SUCCESS = `${ACTION_PREFIX}/LOAD_MODEL_OPTIONS_SUCCESS`;
export const LOAD_TABLE_OPTIONS_SUCCESS = `${ACTION_PREFIX}/LOAD_TABLE_OPTIONS_SUCCESS`;

// Actions

export const loadDateOptions = () => ({
  type: [LOAD_DATE_OPTIONS_SUCCESS],
  // endpoint: `${window.$ctx}/assets/static/data/date-months.json`,
  endpoint: `${window.$ctx}/price/msrpQuery/getInitDate.do`,
});

export const loadBodyOptions = () => ({
  type: [LOAD_BODY_OPTIONS_SUCCESS],
  // endpoint: `${window.$ctx}/assets/static/data/body.json`,
  endpoint: `${window.$ctx}/commonNew/getSubModelBodyTypeListInfo.do`,
});

export const loadModelOptions = data => ({
  type: [LOAD_MODEL_OPTIONS_SUCCESS],
  endpoint: {
    // url: `${window.$ctx}/assets/static/data/models.json`,
    url: `${window.$ctx}/price/msrpQueryCommon/getSubModelListInfo.do`,
    data,
  },
});

export const loadTableOptions = (data, analysisType, startTime, endTime, page) => ({
  type: [LOAD_TABLE_OPTIONS_SUCCESS],
  endpoint: {
    // url: `${window.$ctx}/price/msrpQuery/getMsrpData.do`,
    url: page ? `${window.$ctx}/assets/static/data/msrp-search/table.json` :
                `${window.$ctx}/assets/static/data/msrp-search/table.json`,
    data,
  },
  analysisType,
  startTime,
  endTime,
  page,
});
