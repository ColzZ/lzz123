import React, { PropTypes } from 'react';

import './style';
import GroupList from './GroupList';
import Option from '../../../../components/DropdownSelector/PopoverContent/Option';

export default class AreaCitiesContent extends GroupList {
  static propTypes = {
    className: PropTypes.string,
    allText: PropTypes.string,
  }

  constructor(props) {
    super(props);
    this.state = {
      fastSelect: 1,
      fastSelectOptions: { value: 1, text: '全选', checked: false, id: '-1' },
      tof: true,
    };
  }

  componentWillMount() {
    const { allText } = this.props;
    const { fastSelectOptions } = this.state;
    if (allText) {
      this.setState({ fastSelectOptions: { ...fastSelectOptions, text: allText } });
    }
  }

  componentWillUpdate(nextProps, nextState) {
    const { tof, fastSelectOptions } = nextState;
    // 全选城市时
    if (tof !== this.state.tof) {
      if (fastSelectOptions.checked) {
        const options = nextProps.options.map(group => ({
          ...group,
          checked: true,
        }));
        this.props.onSelect(options);
      } else {
        const options = nextProps.options.map(group => ({
          ...group,
          checked: false,
        }));
        this.props.onSelect(options);
      }
    }
    // 城市选择发生改变时
    if (this.props.options !== nextProps.options) {
      const { fastSelectOptions } = this.state;
      const selectedAllOptions = nextProps.options.every(group => group.checked);
      // const selectedAllOptionsFalse = nextProps.options.every(group => group.checked === false);
      // console.log(selectedAllOptions, selectedAllOptionsFalse);
      if (selectedAllOptions !== fastSelectOptions.checked) {
        if (selectedAllOptions) {
          this.setState({
            fastSelectOptions: {
              ...fastSelectOptions,
              checked: true,
            },
          });
        } else {
          this.setState({
            fastSelectOptions: {
              ...fastSelectOptions,
              checked: false,
            },
          });
        }
      }
    }
  }

  onClickAll() {
    const { fastSelectOptions } = this.state;
    const checked = !fastSelectOptions.checked;
    this.setState({ fastSelectOptions: { ...fastSelectOptions, checked }, tof: !this.state.tof });
  }

  render() {
    const { className = '' } = this.props;
    const { fastSelectOptions } = this.state;
    return (
      <div className={`dropdown-selector-area-cities ${className} oneLevel-L`}>
        <Option
          id={fastSelectOptions.id}
          key={fastSelectOptions.id}
          text={fastSelectOptions.text}
          checked={fastSelectOptions.checked}
          className="allAll-L"
          onClick={() => this.onClickAll()}
        />
        {super.render()}
      </div>
    );
  }
}
