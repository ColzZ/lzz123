import _ from 'lodash';
import React, { Component } from 'react';

import DropdownSelector from '../../../../components/DropdownSelector2';
import TopGroupBottomList from '../../../../components/DropdownSelector/PopoverContent/TopGroupBottomList';
import FastGo from '../components/FastGo';
import Searchbar from '../components/Searchbar';
import Scrollbar from '../components/Scrollbar';
import SelectedOptionsBar from '../components/SelectedOptionsBar';

export default class ManfBrands extends Component {
  constructor(props) {
    super(props);
    this.state = {
      keyword: '',
    };
  }

  /**
   * 获取全部已选项并平面化，便于其它操作统计结果
   * @param  {array} options 被操作的选项数组
   * @return {array}         已过滤已选项并平面化后的选项结果数组
   */
  getSelectedOptions(options) {
    return _.flatten(options.map(group => group.list)).filter(item => item.checked);
  }

  getFastGo(options) {
    const fastGoOptions = options.map(m => ({
      value: m.text,
      text: m.text,
    }));

    if (fastGoOptions.length > 1) {
      return (
        <FastGo
          options={fastGoOptions}
          scrollbar={this.refScrollbar}
        />
      );
    }
    return undefined;
  }

  getContent = ({ multiple, filteredOptions, options, onSelect }) => (
    <div>
      <SelectedOptionsBar
        options={this.getSelectedOptions(options)}
        onRemove={id => this.removeOptionFromSelectedOptionsBar(id, options, onSelect)}
      />
      <div className="tool-bar clearfix">
        {this.getFastGo(filteredOptions)}
        <Searchbar onChange={keyword => this.setState({ keyword })} />
      </div>
      <Scrollbar ref={ref => { this.refScrollbar = ref ? ref.refScrollbar : null; }}>
        <TopGroupBottomList
          multiple={multiple}
          vblOptions={filteredOptions}
          options={options}
          onSelect={onSelect}
        />
      </Scrollbar>
    </div>
  )

  removeOptionFromSelectedOptionsBar = (id, options, onSelect) => {
    const nextOptions = options.map(group => ({
      ...group,
      list: group.list.map(item => ({
        ...item,
        checked: item.id === id ? false : item.checked,
      })),
    }));
    onSelect(nextOptions);
  }

  filter = options => {
    const keyword = this.state.keyword.toLowerCase();
    return options.reduce((arr, group) => {
      const list = group.list.filter(manfBrand => (
        manfBrand.text.toLowerCase().indexOf(keyword) > -1
      ));

      if (list.length > 0) {
        arr.push({
          ...group,
          list,
        });
      }

      return arr;
    }, []);
  }

  render() {
    return (
      <DropdownSelector
        {...this.props}
        title="厂商品牌"
        placeholder="选择厂商品牌"
        selectedText="已选厂商品牌"
        getSelectedOptions={this.getSelectedOptions}
        getContent={this.getContent}
        filter={this.filter}
      />
    );
  }
}
