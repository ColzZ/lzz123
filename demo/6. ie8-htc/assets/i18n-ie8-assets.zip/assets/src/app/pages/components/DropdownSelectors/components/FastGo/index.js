import $ from 'jquery';
import React, { Component, PropTypes } from 'react';
import DropdownMenu from '../../../../../components/DropdownMenu';
import './style';

export default class FastGo extends Component {
  handleSelectLetter = value => {
    const $scrollbar = $(this.props.scrollbar.refScrollbar || this.props.scrollbar);

    if ($scrollbar.find(`[data-fast-go="${value}"]`).length === 0) {
      throw new Error(`找不到定位点 [data-fast-go="${value}"]`);
    }

    const { top } = $scrollbar.find(`[data-fast-go="${value}"]`).position();
    $scrollbar.scrollTop(top + $scrollbar.scrollTop());
  }

  render() {
    const { className = '', options, type } = this.props;

    return type === 'select' ?
      <DropdownMenu
        className={`${className}`}
        options={options}
        onSelect={value => this.handleSelectLetter(value)}
        placeholder={__('newEP.fastPositioning')}
      />
      : <ul className={`popup-menu-fast-go ${className}`}>
        {options.map(option => (
          <li
            key={option.value}
            onClick={() => this.handleSelectLetter(option.text)}
          >
            {option.text}
          </li>
        ))}
      </ul>;
  }
}

FastGo.propTypes = {
  className: PropTypes.string,
  options: PropTypes.array.isRequired,
  scrollbar: PropTypes.object,
  type: PropTypes.string,
};
