import _ from 'lodash';
import React, { PropTypes } from 'react';
import './style';
import Super from './Super';
import Tabs from '../../../components/Tabs';
import Tab from '../../../components/Tab';
import DropdownMenu from '../../../components/DropdownMenu';
import DropdownPanel from '../../../components/DropdownPanel';
import TabByMyAndVs from './TabByMyAndVs';
import TabByMarkets from './TabByMarkets';
import TabByBrands from './TabByBrands';
import TabByManfs from './TabByManfs';
import TabContentSuper from './TabContentSuper';
import SelectedOptionsBar from '../DropdownSelectors/components/SelectedOptionsBar';

export default class PopoverModels extends Super {
  static propTypes = {
    className: PropTypes.string,
    options: PropTypes.array.isRequired,
    onSubmit: PropTypes.func,
    button: PropTypes.node,
    dropdownDirection: PropTypes.string,
    enableCheckAll: PropTypes.bool,
  }

  static findModelList(options, allLevel) {
    const lv1 = _.flatten(options.map(({ list }) => list));
    const lv2 = _.flatten(lv1.map(({ list }) => list));
    return allLevel ? lv1.concat(lv2) : lv2;
  }

  static findAllOptions(options) {
    // const byMyAndVs = PopoverModels.findModelList(options[0], true);
    // const byMarkets = PopoverModels.findModelList(options[1]);
    // const byBrands = PopoverModels.findModelList(options[2]);
    // return byMyAndVs.concat(byMarkets, byBrands);

    return PopoverModels.findModelList(options[1]);
  }

  static findSelectedOptions(options) {
    return PopoverModels.findAllOptions(options).filter(model => model.checked);
  }

  constructor(props) {
    super(props);

    this.state = {
      tabActiveKey: 1,
      options: [[], [], [], []],
      vblOptions: [[], [], [], []],
    };
  }

  submitManfs(options) {
    this.setState({ options });
  }

  getSelectedSize() {
    return PopoverModels.findSelectedOptions(this.state.options).length;
  }

  hasSelected() {
    return this.getSelectedSize() > 0 ? 'has-selected' : '';
  }

  getToggleText() {
    const selectedOptions = PopoverModels.findSelectedOptions(this.state.options);
    const size = selectedOptions.length;
    let checkedCountText = '';
    if (size === 1) {
      return selectedOptions[0].text;
    } else if (size > 1) {
      checkedCountText = size > 0 ? `(${size}个)` : '';
      return `已选车型${checkedCountText}`;
    }
    return checkedCountText;
  }

  getTips() {
    const { vblOptions } = this.state;
    const models = PopoverModels.findAllOptions(vblOptions);
    return models.every(model => !model.checked) ? '请至少选择一个车型' : '';
  }

  clearSelected() {
    this.setState({
      vblOptions: [
        this.state.options[0].map(group => ({
          ...group,
          list: group.list.map(manf => ({
            ...manf,
            list: manf.list.map(model => ({
              ...model,
              checked: false,
            })),
            checked: false,
          })),
        })),
        this.state.options[1].map(group => ({
          ...group,
          list: group.list.map(manf => ({
            ...manf,
            list: manf.list.map(model => ({
              ...model,
              checked: false,
            })),
          })),
        })),
        this.state.options[2].map(group => ({
          ...group,
          list: group.list.map(manf => ({
            ...manf,
            list: manf.list.map(model => ({
              ...model,
              checked: false,
            })),
          })),
        })),
        this.state.options[3].map(group => ({
          ...group,
          list: group.list.map(manf => ({
            ...manf,
            list: manf.list.map(model => ({
              ...model,
              checked: false,
            })),
          })),
        })),
      ],
    });
  }

  handleSubmit = () => {
    const { tabActiveKey, vblOptions } = this.state;
    const { onSubmit } = this.props;
    const selectedOptions = PopoverModels.findSelectedOptions(vblOptions);
    const ids = selectedOptions.map(manf => manf.id).join(',');
    if (ids) {
      this.submitManfs(vblOptions);
      const texts = selectedOptions.map(manf => manf.text).join(',');
      if (onSubmit) onSubmit({ type: tabActiveKey, ids, texts });
      this.refElm.handleClose();
    }
  }

  removeOptionFromSelectedOptionsBar = id => {
    const { vblOptions } = this.state;
    const nextVblOptions = vblOptions.map(tab => (TabContentSuper.checkChildren(tab, id)));
    this.setVblOptions(nextVblOptions);
  }

  render() {
    const { vblOptions, tabActiveKey } = this.state;
    const { className = '', button, dropdownDirection, enableCheckAll } = this.props;
    const footerTips = this.getTips();

    return (
      <DropdownMenu
        ref={ref => { this.refElm = ref; }}
        className={`dropdown-menu-selector ${className} ${this.hasSelected()}`}
        text={this.getToggleText()}
        button={button}
        menuStyle={{ width: 600 }}
        multiple
        onOpen={this.resetVblOptions}
        dropdownDirection={dropdownDirection}
      >
        <DropdownPanel
          multiple
          onSubmit={this.handleSubmit}
          footerTips={footerTips}
          onReset={() => this.clearSelected()}
        >
          <SelectedOptionsBar
            options={PopoverModels.findSelectedOptions(vblOptions)}
            onRemove={this.removeOptionFromSelectedOptionsBar}
          />
          <Tabs activeKey={tabActiveKey} onSelect={this.handleSelectTab} style={{ position: 'relative' }}>
            <Tab title="本品及竞品" eventKey={1}>
              {tabActiveKey === 1 &&
                <TabByMyAndVs
                  options={vblOptions}
                  updateOptions={this.setVblOptions}
                  enableCheckAll={enableCheckAll}
                />
              }
            </Tab>
            <Tab title="细分市场" eventKey={2}>
              {tabActiveKey === 2 &&
                <TabByMarkets
                  options={vblOptions}
                  updateOptions={this.setVblOptions}
                  enableCheckAll={enableCheckAll}
                />
              }
            </Tab>
            <Tab title="厂商" eventKey={3}>
              {tabActiveKey === 3 &&
                <TabByManfs
                  options={vblOptions}
                  updateOptions={this.setVblOptions}
                  enableCheckAll={enableCheckAll}
                />
              }
            </Tab>
            <Tab title="品牌" eventKey={4}>
              {tabActiveKey === 4 &&
                <TabByBrands
                  options={vblOptions}
                  updateOptions={this.setVblOptions}
                  enableCheckAll={enableCheckAll}
                />
              }
            </Tab>
          </Tabs>
        </DropdownPanel>
      </DropdownMenu>
    );
  }
}
