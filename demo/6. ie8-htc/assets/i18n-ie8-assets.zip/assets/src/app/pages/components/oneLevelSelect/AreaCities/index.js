import React from 'react';

import GroupListSelector from '../../../../components/DropdownSelector/Selectors/GroupListL';
import AreaCitiesContent from './Content';

export default class AreaCities extends GroupListSelector {
  placeholder = '选择城市'

  selectedText = '已选城市'
  /**
   * 获取全部已选项
   */
  getSelectedOptions = options => {
    const checkOptions = options.filter(item => item.checked);
    if (checkOptions.length > 0) {
      return checkOptions;
    }
    return [{ id: '-1', text: '全选', checked: true }];
  }

  getContent() {
    const { multiple, title, allText, selectedText } = this.props;
    const { options } = this.state;
    if (selectedText) this.selectedText = selectedText;
    return (
      <AreaCitiesContent
        options={options}
        multiple={multiple}
        onSelect={this.select}
        title={title}
        allText={allText}
      />
    );
  }
}
