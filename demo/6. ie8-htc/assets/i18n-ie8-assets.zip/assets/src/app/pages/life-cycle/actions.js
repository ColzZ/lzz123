const ACTION_PREFIX = module.id;

export const LC_ACTION = `${ACTION_PREFIX}/LC_ACTION`;
export const action = data => ({
  type: [LC_ACTION],
  data,
});
