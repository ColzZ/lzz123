import { Component, PropTypes } from 'react';

export default class PopupMenuManfs extends Component {
  static propTypes = {
    options: PropTypes.array.isRequired,
  }

  componentWillMount() {
    const { options } = this.props;
    this.setState({ options, vblOptions: options });
  }

  componentWillReceiveProps(nextProps) {
    const { options } = nextProps;
    if (this.props.options !== options) {
      this.setState({ options, vblOptions: options });
    }
  }

  setVblOptions = vblOptions => {
    this.setState({
      vblOptions,
    });
  }

  resetVblOptions = vblOptions => {
    this.setVblOptions(vblOptions || this.state.options);
  }

  handleSelectTab = tabActiveKey => {
    this.setState({ tabActiveKey });
  }
}
