import _ from 'lodash';
import React, { PropTypes } from 'react';

import SelectorTable from '../../../../components/DropdownSelector/PopoverContent/SelectorTable';
import PopoverContent from '../../../../components/DropdownSelector/PopoverContent/PopoverContent';

export default class TopGroupBottomListPopoverContent extends PopoverContent {
  static propTypes = {
    ...PopoverContent.propTypes,
    className: PropTypes.string,
    options: PropTypes.array.isRequired,
  }

  static getSelectedOptions = options => {
    if (!options) return [];
    return _.flatten(options.map(group => group.list)).filter(item => item.checked);
  }

  checkGroup = groupId => this.props.options.map(group => {
    if (groupId === group.id) {
      const { checked, list } = group;
      return {
        ...group,
        checked: !checked,
        list: list.map(item => ({
          ...item,
          checked: !checked,
        })),
      };
    }
    return group;
  })

  checkOption = value => {
    const { multiple } = this.props;

    return this.props.options.map(group => {
      const list = group.list.map(item => {
        if (multiple) {
          if (item.id === value) {
            return {
              ...item,
              checked: !item.checked,
            };
          }
          return item;
        }
        return {
          ...item,
          checked: item.id === value,
        };
      });
      return {
        ...group,
        checked: list.every(item => item.checked),
        list,
      };
    });
  }

  render() {
    const { options } = this.props;

    return (
      <div>
        {options.map((group, index) => (
          <SelectorTable key={group.id || index} style={{ borderBottom: '1px solid #E8E8E8' }}>
            <tbody>
              <tr>
                <td
                  style={{ width: 120 }}
                  data-fast-go={group.text}
                  className="text-center"
                >
                  {this.getOption(group, this.checkGroup)}
                </td>
                <td className="no-padding">
                  <SelectorTable>
                    <tbody>
                      {group.list.map(item => (
                        <tr key={item.id}>
                          <td>{this.getOption(item)}</td>
                          <td className="text-center" style={{ width: 80 }}>{item.msrp}</td>
                          <td className="text-center" style={{ width: 80 }}>{item.mix}</td>
                        </tr>
                      ))}
                    </tbody>
                  </SelectorTable>
                </td>
              </tr>
            </tbody>
          </SelectorTable>
        ))}
      </div>
    );
  }
}
