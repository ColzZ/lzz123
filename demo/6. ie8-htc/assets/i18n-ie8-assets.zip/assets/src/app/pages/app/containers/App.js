import React, { PropTypes } from 'react';

import Header from '../components/Header';
import Footer from '../components/Footer';
import PageBody from '../components/PageBody';
import Aside from './Aside';

const App = ({ pathname, aside, children }) => {
  const cnAside = aside ? '' : 'aside-closed';
  const cnNoAside = children.props.route.noAside ? 'no-aside' : '';
  return (
    <div className="ways-think-tank-framework">
      <div className={`page-cdo-tool page-wrapper ${cnAside} ${cnNoAside}`}>
        <Header pathname={pathname} />
        {!children.props.route.noAside && <Aside pathname={pathname} />}
        <PageBody>
          {children}
        </PageBody>
        <Footer />
      </div>
    </div>
  );
};

App.propTypes = {
  pathname: PropTypes.string.isRequired,
  aside: PropTypes.bool.isRequired,
  children: PropTypes.node.isRequired,
};

export default App;
