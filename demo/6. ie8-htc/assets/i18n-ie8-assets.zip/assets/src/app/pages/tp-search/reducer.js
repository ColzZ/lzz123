import createReducer from 'createReducer';
import React from 'react';

import {
  LOAD_DATE_OPTIONS_SUCCESS,
  LOAD_CITY_OPTIONS_SUCCESS,
  LOAD_BODY_OPTIONS_SUCCESS,
  LOAD_MANF_BRAND_OPTIONS_SUCCESS,
  LOAD_MODEL_OPTIONS_SUCCESS,
  LOAD_VERSION_OPTIONS_SUCCESS,
  RESTORE_VERSION_OPTIONS,
  LOAD_COMMON_OBJECT_OPTIONS_SUCCESS,
  RESTORE_COMMON_OBJECT_OPTIONS,
  LOAD_TABLE_OPTIONS_SUCCESS,
} from './actions';

const initColumns = [
  { key: 'date', title: <span>日期<br />Date</span>, className: 'text-center' },
  { key: 'patch', title: <span>批次<br />Patch</span>, enTitle: 'patch', className: 'text-center' },
  { key: 'versionCode', title: <span>型号编码<br />Version Code</span>, enTitle: 'versionCode', className: 'text-center' },
  { key: 'segment', title: <span>级别<br />Segment</span>, className: 'text-center' },
  { key: 'brand', title: <span>品牌<br />Brand</span>, className: 'text-center' },
  { key: 'oem', title: <span>生产厂<br />Oem</span>, className: 'text-center' },
  { key: 'model', title: <span>车型<br />Model</span>, className: 'text-center' },
  { key: 'engineCapacity', title: <span>排量<br />Engine Capacity</span>, className: 'text-center' },
  { key: 'transmissionType', title: <span>排档方式<br />Transmission Type</span>, className: 'text-center' },
  { key: 'versionMark', title: <span>型号标识<br />Version Mark</span>, className: 'text-center' },
  { key: 'bodyType', title: <span>车身形式<br />Body Type</span>, className: 'text-center' },
  { key: 'launchDate', title: <span>上市日期<br />Launch Date</span>, className: 'text-center' },
  { key: 'year', title: <span>年式<br />Year</span>, className: 'text-center' },
  { key: 'msrp', title: <span>厂商指导价(元)<br />MSRP</span>, className: 'text-center' },
];

const manfBrandColumns = [
  { key: 'date', title: <span>日期<br />Date</span>, className: 'text-center' },
  { key: 'patch', title: <span>批次<br />Patch</span>, enTitle: 'patch', className: 'text-center' },
  { key: 'brand', title: <span>品牌<br />Brand</span>, className: 'text-center' },
  { key: 'oem', title: <span>生产厂<br />Oem</span>, className: 'text-center' },
  // { key: 'msrp', title: <span>厂商指导价(元)<br />MSRP</span>, className: 'text-center' },
];

const modeColumns = [
  { key: 'date', title: <span>日期<br />Date</span>, className: 'text-center' },
  { key: 'patch', title: <span>批次<br />Patch</span>, enTitle: 'patch', className: 'text-center' },
  { key: 'segment', title: <span>级别<br />Segment</span>, className: 'text-center' },
  { key: 'brand', title: <span>品牌<br />Brand</span>, className: 'text-center' },
  { key: 'oem', title: <span>生产厂<br />Oem</span>, className: 'text-center' },
  { key: 'model', title: <span>车型<br />Model</span>, className: 'text-center' },
  { key: 'bodyType', title: <span>车身形式<br />Body Type</span>, className: 'text-center' },
  // { key: 'msrp', title: <span>厂商指导价(元)<br />MSRP</span>, className: 'text-center' },
];

export default createReducer({
  CONSTRUCT() {
    return {
      dateOptions: [{}, {}],
      cityOptions: [],
      bodyOptions: [],
      manfBrandOptions: [],
      modelOptions: [[], [], [], []],
      versionOptions: [],
      commonObjectOptions: [],
      tableOptions: {
        columns: [],
        data: [],
      },
    };
  },

  [LOAD_DATE_OPTIONS_SUCCESS](state, { response: { data } }) {
    return { ...state, dateOptions: data };
  },

  [LOAD_CITY_OPTIONS_SUCCESS](state, { response: { data } }) {
    return { ...state, cityOptions: data };
  },

  [LOAD_BODY_OPTIONS_SUCCESS](state, { response: { data } }) {
    return { ...state, bodyOptions: data };
  },

  [LOAD_MANF_BRAND_OPTIONS_SUCCESS](state, { response: { data } }) {
    return { ...state, manfBrandOptions: data };
  },

  [LOAD_MODEL_OPTIONS_SUCCESS](state, { response: { data } }) {
    return { ...state, modelOptions: data };
  },

  [LOAD_VERSION_OPTIONS_SUCCESS](state, { response: { data } }) {
    return { ...state, versionOptions: data };
  },

  [RESTORE_VERSION_OPTIONS](state) {
    return { ...state, versionOptions: [...state.versionOptions] };
  },

  [LOAD_COMMON_OBJECT_OPTIONS_SUCCESS](state, { response: { data } }) {
    return { ...state, commonObjectOptions: data };
  },

  [RESTORE_COMMON_OBJECT_OPTIONS](state) {
    return { ...state, commonObjectOptions: [...state.commonObjectOptions] };
  },

  [LOAD_TABLE_OPTIONS_SUCCESS](state, {
    response: { data },
    selectedCityOptions,
    page,
    analysisType,
  }) {
    let columns = initColumns;
    if (analysisType === 1) {
      columns = manfBrandColumns;
    } else if (analysisType === 2) {
      columns = modeColumns;
    }

    // 全国
    if (selectedCityOptions.length === 1 && selectedCityOptions[0].id === '-1') {
      columns = columns.concat({
        key: 'countryAvg',
        title: <span>全国均价<br />Country Avg</span>,
        className: 'text-center',
      });
    // 分城市
    } else {
      const cityColumns = selectedCityOptions.map(city => ({
        key: `city${city.id}`,
        title: <span>{city.text}<br />{city.textEn.toUpperCase()}</span>,
        className: 'text-center',
      }));
      columns = columns.concat(cityColumns, [
        { key: 'citiesAvg', title: <span>所选城市算术平均价<br />Cities Avg</span>, className: 'text-center' },
        { key: 'citiesMixAvg', title: <span>所选城市加权平均价<br />Cities MixAvg</span>, className: 'text-center' },
      ]);
    }

    const nextData = page ? state.tableOptions.data.concat(data) : data;

    return { ...state, tableOptions: { ...state.tableOptions, columns, data: nextData } };
  },
});
