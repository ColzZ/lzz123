import $ from 'jquery';
import React, { Component, PropTypes } from 'react';

import 'jquery.scrollbar';
import './style';

export default class SelectedOptionsBar extends Component {
  static propTypes = {
    options: PropTypes.array.isRequired,
    onRemove: PropTypes.func.isRequired,
  }

  componentWillReceiveProps(nextProps) {
    if (this.props.options !== nextProps.options) {
      // 修复 IE8 下 max-height 无法生效问题，强制重置 max-height
      setTimeout(() => {
        const contentHeight = $(this.refContent).outerHeight();
        if (contentHeight > 78) {
          $(this.refScrollbar).scrollbar();
        }
        const height = contentHeight < 78 ? contentHeight : 78;
        $(this.refScrollbar)
        .css({ 'max-height': height })
        .closest('.scroll-wrapper').css({ 'max-height': height });
      }, 0);
    }
  }

  render() {
    const { options, onRemove } = this.props;

    return (
      <div
        className="selected-options-bar scrollbar-inner"
        ref={ref => { this.refScrollbar = ref; }}
      >
        {options.length > 0 &&
          <div
            className="selected-options-bar-wrapper"
            ref={ref => { this.refContent = ref; }}
          >
            {__('newEP.selectedModels')}：
            {options.map(({ id, text }) => (
              <div
                className="selected-option"
                key={id}
                onClick={() => onRemove(id)}
              >
                {text} ×
              </div>
            ))}
          </div>
        }
      </div>
    );
  }
}
