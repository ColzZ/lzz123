import { connect } from 'react-redux';

import {
  loadDateOptions,
  loadBodyOptions,
  loadModelOptions,
  loadTableOptions,
} from './actions';

import MsrpSearch from './components/MsrpSearch';

export default connect(
  state => state.msrpSearch,
  {
    loadDateOptions,
    loadBodyOptions,
    loadModelOptions,
    loadTableOptions,
  }
)(MsrpSearch);
