import _ from 'lodash';
import $ from 'jquery';
import React, { Component, PropTypes } from 'react';
import { connect } from 'react-redux';
import { stringify } from 'querystring';
import DownLoadExcel from '../components/DownloadExcel';
import Toolbar from '../../components/Toolbar';
import Form from '../../components/Form';
import Button from '../../components/Button';
import FormGroup from '../../components/FormGroup';
import AreaCities from '../components/oneLevelSelect/AreaCities';
import PopoverModels from '../components/PopoverModelsL';
import Table from './../../components/Table';
import {
  getDateOptions,
  getCityOptions,
  getModelOptions,
  getShowOrHideOptions,
  getListOptions,
  clean,
} from './actions';
import './style';

class NewEnergyPage extends Component {
  static propTypes = {
    getDateOptions: PropTypes.func.isRequired,
    dateOptions: PropTypes.array.isRequired,
    getCityOptions: PropTypes.func.isRequired,
    cityOptions: PropTypes.array.isRequired,
    getModelOptions: PropTypes.func.isRequired,
    modelOptions: PropTypes.array.isRequired,

    getShowOrHideOptions: PropTypes.func.isRequired,
    showOrHide: PropTypes.array.isRequired,
    getListOptions: PropTypes.func.isRequired,
    listOptions: PropTypes.object.isRequired,
    clean: PropTypes.func.isRequired,
  }

  constructor(props) {
    super(props);

    this.state = {
      data: true,
      dateStart: '',
      dateEnd: '',
      dateSelect: '',
      dateOptions: [{}, {}],    // 时间月份到月份 Options
      month: 1,
      monthOptions: [{ text: __('newEP.halfMonths'), value: 1, checked: true }, { text: __('newEP.month'), value: 2 }],
      cityIds: '',
      cityOptions: [],
      modelIds: '',
      modelOptions: [],
      showOrHide: [],
      showIds: '1,2,3,4,7,8,9,10,11,17,25,26,29,30,31,32,33,36,37,38',
      showType: '',
      tableOptions: {},
      lang: '',
      tof: true,
      tofL: true,
    };
  }


  componentWillMount() {
    // $('body').showLoading();
    let lang = $('html').attr('lang');
    if (lang === 'en') {
      lang = '_en';
    } else {
      lang = '';
    }
    this.props.getDateOptions({ lang });
    this.props.getCityOptions({ lang });
  }

  componentWillReceiveProps(nextProps) {
    const { dateOptions, cityOptions, modelOptions, showOrHide, listOptions } = nextProps;
    if (dateOptions !== this.props.dateOptions || cityOptions !== this.props.cityOptions) {
      const cityIds = cityOptions.filter(item => item.checked).map(val => val.id).join(',');
      this.setState({ dateOptions, cityOptions, cityIds });
    }
    if (dateOptions !== this.props.dateOptions) {
      const { select } = dateOptions[0];
      this.setState({ dateSelect: select });
    }
    if (modelOptions !== this.props.modelOptions) {
      const modelIds = _.flatten(
        _.flatten(modelOptions[0].map(group => group.list)).map(group => group.list))
        .filter(item => item.checked).map(val => val.id).join(',');
      this.setState({ modelOptions, modelIds });
    }
    if (showOrHide !== this.props.showOrHide) {
      this.setState({ showOrHide });
    }
    if (listOptions !== this.props.listOptions) {
      const { columns, data } = listOptions;
      this.setState({ tableOptions: { columns, data } });
      $('body').hideLoading();
    }
  }

  componentWillUpdate(nextProps, nextState) {
    const { dateStart, dateEnd, dateSelect,
      month, modelIds, cityIds, showIds, tof, tofL } = nextState;
    let lang = $('html').attr('lang');
    if (lang === 'en') {
      lang = '_en';
    } else {
      lang = '';
    }
    if (tofL && dateStart && dateEnd && cityIds &&
      (dateStart !== this.state.dateStart ||
       dateEnd !== this.state.dateEnd ||
       cityIds !== this.state.cityIds)) {
      this.setState({ modelIds: '' });
      this.props.getModelOptions({ dateStart, dateEnd, dateSelect, cityIds, lang });
      this.setState({ tofL: false });
    }
    if (tof && month && modelIds && showIds &&
      (month !== this.state.month ||
      modelIds !== this.state.modelIds ||
      showIds !== this.state.showIds)
    ) {
      $('body').showLoading();
      const data = { dateStart, dateEnd, dateSelect, month, modelIds, cityIds, showIds, lang };
      this.props.getListOptions(data);
      this.setState({ tof: false });
    }
    if (showIds !== this.state.showIds) {
      $('body').showLoading();
      const data = { dateStart, dateEnd, dateSelect, month, modelIds, cityIds, showIds, lang };
      this.props.getListOptions(data);
    }
  }

  componentWillUnmount() {
    this.props.clean();
  }

  onMonthChange(dateStart, dateEnd) {
    const { showType } = this.state;
    const showTypeL = dateStart === dateEnd;
    if (showType !== showTypeL) {
      this.props.getShowOrHideOptions(!showTypeL);
      this.setState({ dateStart, dateEnd, showType: showTypeL, showIds: '1,2,3,4,7,8,9,10,11,17,25,26,29,30,31,32,33,36,37,38' });
    } else {
      this.setState({ dateStart, dateEnd });
    }
  }

  onLoading() {
    $('body').showLoading();
    const { dateStart, dateEnd, dateSelect, month, modelIds, cityIds, showIds } = this.state;
    let lang = $('html').attr('lang');
    if (lang === 'en') {
      lang = '_en';
    } else {
      lang = '';
    }
    this.props.getListOptions({
      dateStart, dateEnd, dateSelect, month, modelIds, cityIds, showIds, lang });
  }

  downLoad() {
    const { dateStart, dateEnd, dateSelect, month, modelIds, cityIds, showIds } = this.state;
    let lang = $('html').attr('lang');
    if (lang === 'en') {
      lang = '_en';
    } else {
      lang = '';
    }
    return `${window.$ctx}/exportExcel.do?${stringify({ dateStart, dateEnd, dateSelect, month, modelIds, cityIds, showIds, lang })}`;
  }

  render() {
    let height;
    if (window.innerHeight !== undefined) {
      height = window.innerHeight;
    } else {
      const B = document.body;
      const D = document.documentElement;
      height = Math.min(D.clientHeight, B.clientHeight);
    }
    const heightL = height - 214;
    const { dateOptions, modelOptions, cityOptions, monthOptions, showOrHide,
      tableOptions } = this.state;
    return (
      <div className="new-eneigu-page">
        <Toolbar color="white" className="topNav">
          <h2>{__('newEnergyTitle')}</h2>
        </Toolbar>
        <Toolbar color="white" className="topNav">
          <Form inline>
            <FormGroup
              className="mr-30"
              type="monthRange"
              options={dateOptions}
              onSelect={(dateStart, dateEnd) => this.onMonthChange(dateStart, dateEnd)}
            />
            <FormGroup
              className="mr-30"
              type="buttonRadio"
              options={monthOptions}
              onSelect={month => this.setState({ month })}
            />
            <FormGroup label="" className="mr-30">
              {cityOptions[0] &&
                <AreaCities
                  multiple
                  required
                  className="city-one-level-l one-level-l"
                  options={cityOptions}
                  onSelect={value => this.setState({ cityIds: value.ids })}
                  title={__('newEP.selectCity')}
                  allText={__('newEP.selectAll')}
                  tipsText={__('newEP.selectAtLeastOne')}
                  selectedText={__('newEP.selectedCity')}
                />
              }
            </FormGroup>
            <FormGroup
              className="mr-20"
            >
              {modelOptions[0] &&
                <PopoverModels
                  options={modelOptions}
                  onSubmit={value => this.setState({ modelIds: value.ids })}
                />
              }
            </FormGroup>
            <Button className="btn-primary mr-20 btn-icon" onClick={() => { this.onLoading(); }}><i className="iconfont icon-fangdajing iconL" />{__('newEP.search')}</Button>
          </Form>
        </Toolbar>
        <Toolbar color="white" className="topNav topNav-g-L">
          <FormGroup
            className="d-ib ml-20 mr-20"
          >
            {showOrHide[0] &&
              <AreaCities
                multiple
                required
                className="showOrHide one-level-l"
                options={showOrHide}
                onSelect={value => this.setState({ showIds: value.ids })}
                title={__('newEP.showTof')}
                allText={__('newEP.selectAll')}
                tipsText={__('newEP.selectAtLeastOne')}
                selectedText={__('newEP.selectedShow')}
              />
            }
          </FormGroup>
          {window.exportAuth === 'yes' &&
            <DownLoadExcel className="pull-right" href={this.downLoad()} />
          }
        </Toolbar>
        <Table
          className="table-l"
          options={tableOptions}
          // fixedTableAside={fixedTableAside}
          loading
          freezeHeader
          // freezeColumn={1}
          scrollY={heightL}
          autoExpand
          ref={ref => { this.refTable = ref; }}
        />
      </div>
    );
  }
}
function mapStateToProps(state) {
  const { newEnergyPage } = state;
  return {
    ...newEnergyPage,
  };
}

export default connect(mapStateToProps, {
  getDateOptions,
  getCityOptions,
  getModelOptions,
  getShowOrHideOptions,
  getListOptions,
  clean,
})(NewEnergyPage);
