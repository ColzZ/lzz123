import React, { Component, PropTypes } from 'react';
import './style';

export default class Aside extends Component {
  static propTypes = {
    pathname: PropTypes.string.isRequired,
    options: PropTypes.array.isRequired,
    toggle: PropTypes.func.isRequired,
  }

  render() {
    const { pathname, toggle, options } = this.props;

    return (
      <div className="page-aside">
        <ul className="nav" ref={ref => (this.refNav = ref)}>
          {options.map(({ title, list }, gIndex) => (
            <li key={gIndex}>
              <a className="title">{title}</a>
              <ul className="list">
                {list.map(({ path, text }, index) => {
                  const className = path === `#${pathname}` ? 'active' : '';
                  return (
                    <li key={index} className={className}>
                      <a href={path}>{text}</a>
                    </li>
                  );
                })}
              </ul>
            </li>
          ))}
        </ul>
        <div className="btn-close" onClick={() => toggle()}><div className="icon" /></div>
      </div>
    );
  }
}
