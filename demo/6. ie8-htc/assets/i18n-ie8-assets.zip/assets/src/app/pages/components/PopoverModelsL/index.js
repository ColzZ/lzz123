import _ from 'lodash';
import React, { PropTypes } from 'react';
import './style';
import Super from './Super';
import Tabs from '../../../components/Tabs';
import Tab from '../../../components/Tab';
import DropdownMenu from '../../../components/DropdownMenu';
import DropdownPanel from '../../../components/DropdownPanel';
// import TabByMyAndVs from './TabByMyAndVs';
import TabByMarkets from './TabByMarkets';
import TabByManfs from './TabByManfs';
import TabByBrands from './TabByBrands';
import TabContentSuper from './TabContentSuper';
import SelectedOptionsBar from '../DropdownSelectors/components/SelectedOptionsBar';

export default class PopoverModelsL extends Super {
  static propTypes = {
    className: PropTypes.string,
    options: PropTypes.array.isRequired,
    onSubmit: PropTypes.func,
    button: PropTypes.node,
  }
  // 11 如果有all 返回第1第2-list  没有就返回第2-list
  static findModelList(options, allLevel) {
    const lv1 = _.flatten(options.map(({ list }) => list));
    const lv2 = _.flatten(lv1.map(({ list }) => list));
    return allLevel ? lv1.concat(lv2) : lv2;
  }
  // 10-对细分市场进行处理
  static findAllOptions(options) {
    return PopoverModelsL.findModelList(options[0]);
  }
  // 9 获取所有选择的
  static findSelectedOptions(options) {
    return PopoverModelsL.findAllOptions(options).filter(model => model.checked);
  }

  constructor(props) {
    super(props);

    this.state = {
      tabActiveKey: 1,
      options: [[], [], []],    // 这个是默认的
      vblOptions: [[], [], []], // 这个是走的
    };
  }
  // 8
  submitManfs(options) {
    this.setState({ options });
  }
  // 7 获取已经选择的选项的长度
  getSelectedSize() {
    return PopoverModelsL.findSelectedOptions(this.state.options).length;
  }
  // 6 查看细分市场是否有已经选择的
  hasSelected() {
    return this.getSelectedSize() > 0 ? 'has-selected' : '';
  }
  // 5 获取选择了的个数
  getToggleText() {
    const size = this.getSelectedSize();
    const checkedCountText = size > 0 ? `(${size}个)` : '';
    return `${__('newEP.selectedModel')}${checkedCountText}`;
  }

  // 4 加载完数据执行的方法
  getTips() {
    const { vblOptions } = this.state;
    const models = PopoverModelsL.findAllOptions(vblOptions);
    const modelsL = __('newEP.selectAtLeastOneModel');
    return models.every(model => !model.checked) ? modelsL : '';
  }
  // 3 这个是清除所有
  clearSelected() {
    this.setState({
      vblOptions: [
        this.state.options[0].map(group => ({
          ...group,
          list: group.list.map(manf => ({
            ...manf,
            list: manf.list.map(model => ({
              ...model,
              checked: false,
            })),
            checked: false,
          })),
        })),
        this.state.options[1].map(group => ({
          ...group,
          list: group.list.map(manf => ({
            ...manf,
            list: manf.list.map(model => ({
              ...model,
              checked: false,
            })),
          })),
        })),
        this.state.options[2].map(group => ({
          ...group,
          list: group.list.map(manf => ({
            ...manf,
            list: manf.list.map(model => ({
              ...model,
              checked: false,
            })),
          })),
        })),
        // this.state.options[3].map(group => ({
        //   ...group,
        //   list: group.list.map(manf => ({
        //     ...manf,
        //     list: manf.list.map(model => ({
        //       ...model,
        //       checked: false,
        //     })),
        //   })),
        // })),
      ],
    });
  }
  // 2 点击确定选择的时候会触发-赋值
  handleSubmit = () => {
    const { tabActiveKey, vblOptions } = this.state;
    const { onSubmit } = this.props;
    const selectedOptions = PopoverModelsL.findSelectedOptions(vblOptions);
    const ids = selectedOptions.map(manf => manf.id).join(',');
    if (ids) {
      this.submitManfs(vblOptions);
      const texts = selectedOptions.map(manf => manf.text).join(',');
      if (onSubmit) onSubmit({ type: tabActiveKey, ids, texts });
      this.refElm.handleClose();
    }
  }
  // 1 上方点击清除的时候会触发
  removeOptionFromSelectedOptionsBar = id => {
    const { vblOptions } = this.state;
    const nextVblOptions = vblOptions.map(tab => (TabContentSuper.checkChildren(tab, id)));
    this.setVblOptions(nextVblOptions);
  }

  render() {
    const { vblOptions, tabActiveKey } = this.state;
    const { className = '', button } = this.props;
    const footerTips = this.getTips();

    return (
      <DropdownMenu
        ref={ref => { this.refElm = ref; }}
        className={`dropdown-menu-selector ${className} ${this.hasSelected()}`}
        text={this.getToggleText()}
        button={button}
        menuStyle={{ width: 600 }}
        multiple
        onOpen={this.resetVblOptions}
      >
        <DropdownPanel
          multiple
          onSubmit={this.handleSubmit}
          footerTips={footerTips}
          onReset={() => this.clearSelected()}
        >
          <SelectedOptionsBar
            options={PopoverModelsL.findSelectedOptions(vblOptions)}
            onRemove={this.removeOptionFromSelectedOptionsBar}
          />
          <Tabs activeKey={tabActiveKey} onSelect={this.handleSelectTab} style={{ position: 'relative' }}>
            {
              // <Tab title="本品及竞品" eventKey={1}>
              //   {tabActiveKey === 1 &&
              //     <TabByMyAndVs options={vblOptions} updateOptions={this.setVblOptions} />
              //   }
              // </Tab>

            }
            <Tab title={__('newEP.segment')} eventKey={1}>
              {tabActiveKey === 1 &&
                <TabByMarkets options={vblOptions} updateOptions={this.setVblOptions} />
              }
            </Tab>
            <Tab title={__('newEP.brand')} eventKey={2}>
              {tabActiveKey === 2 &&
                <TabByManfs options={vblOptions} updateOptions={this.setVblOptions} />
              }
            </Tab>
            <Tab title={__('newEP.fuelType')} eventKey={3}>
              {tabActiveKey === 3 &&
                <TabByBrands options={vblOptions} updateOptions={this.setVblOptions} />
              }
            </Tab>
          </Tabs>
        </DropdownPanel>
      </DropdownMenu>
    );
  }
}
