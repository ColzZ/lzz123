import $ from 'jquery';
import React, { Component, PropTypes } from 'react';
import { stringify } from 'querystring';
import 'loading';

import Toolbar from '../../../components/Toolbar';
import Form from '../../../components/Form';
import FormGroup from '../../../components/FormGroup';
import Button from '../../../components/Button';
import Table from '../../../components/Table';
import DownloadExcel from '../../../components/DownloadExcel';

import AreaCities from '../../components/DropdownSelectors/AreaCities';
import ManfBrands from '../../components/DropdownSelectors/ManfBrands';
import VersionsByModels from '../../components/DropdownSelectors/VersionsByModels';
import CommonObjects from '../../components/DropdownSelectors/CommonObjects';
import PopoverModels from '../../components/PopoverModels';

export default class TpSearch extends Component {
  static propTypes = {
    // Props
    dateOptions: PropTypes.array.isRequired,
    cityOptions: PropTypes.array.isRequired,
    bodyOptions: PropTypes.array.isRequired,
    manfBrandOptions: PropTypes.array.isRequired,
    modelOptions: PropTypes.array.isRequired,
    versionOptions: PropTypes.array.isRequired,
    commonObjectOptions: PropTypes.array.isRequired,
    tableOptions: PropTypes.object.isRequired,

    // Actions
    loadDateOptions: PropTypes.func.isRequired,
    loadCityOptions: PropTypes.func.isRequired,
    loadBodyOptions: PropTypes.func.isRequired,
    loadManfBrandOptions: PropTypes.func.isRequired,
    loadModelOptions: PropTypes.func.isRequired,
    loadVersionOptions: PropTypes.func.isRequired,
    restoreVersionOptions: PropTypes.func.isRequired,
    loadCommonObjectOptions: PropTypes.func.isRequired,
    restoreObjectOptions: PropTypes.func.isRequired,
    loadTableOptions: PropTypes.func.isRequired,
  }

  static dateTypeOptions = [
    { value: 1, text: '周' },
    { value: 2, text: '半月' },
    { value: 3, text: '月', checked: true },
    { value: 4, text: '季度' },
    { value: 5, text: '年' },
  ]

  static analysisTypeOptions = [
    { value: 1, text: '厂商品牌' },
    { value: 2, text: '车型', checked: true },
    { value: 3, text: '型号' },
  ]

  constructor(props) {
    super(props);
    this.state = {
      tableHeight: 0,
      startTime: '',
      endTime: '',
      dateType: 3,
      cities: '-1',
      selectedCityOptions: [{ id: '-1', text: '全国均价', checked: true }],
      analysisType: 2,
      bodyTypes: '',
      manfBrands: '',
      models: '',
      versions: '',
      commonObjects: '',
    };
  }

  componentWillMount() {
    $('body').showLoading();
    this.setState({ tableHeight: $(window).height() - 179 });
    this.props.loadDateOptions();
    this.props.loadCityOptions();
    this.props.loadBodyOptions();
    this.props.loadCommonObjectOptions();
  }

  componentWillReceiveProps(nextProps) {
    const {
      dateOptions,
      modelOptions,
      versionOptions,
      commonObjectOptions,
      tableOptions,
    } = nextProps;

    if (this.props.dateOptions !== dateOptions) {
      this.setState({ startTime: dateOptions[0].select, endTime: dateOptions[1].select });
    }
    if (this.props.modelOptions !== modelOptions) {
      const models = this.getSelectedModelIds(modelOptions);
      this.setState({ models });
      $('body').hideLoading();
    }
    if (this.props.versionOptions !== versionOptions) {
      this.setState({ versions: '' });
    }
    if (this.props.commonObjectOptions !== commonObjectOptions) {
      this.setState({ commonObjects: '' });
    }

    if (this.props.tableOptions !== tableOptions) {
      $('body').hideLoading();
    }
  }

  // shouldComponentUpdate(nextProps, nextState) {
  //   // manfBrandOptions: PropTypes.array.isRequired,
  //   // modelOptions: PropTypes.array.isRequired,
  //   // versionOptions: PropTypes.array.isRequired,
  //   // commonObjectOptions: PropTypes.array.isRequired,
  //   // tableOptions: PropTypes.object.isRequired,
  //
  //   // this.state = {
  //   //   tableHeight: 0,
  //   //   startTime: '',
  //   //   endTime: '',
  //   //   dateType: 3,
  //   //   cities: '-1',
  //   //   analysisType: 2,
  //   //   bodyTypes: '',
  //   // };
  //
  //   const {
  //     analysisType,
  //   } = nextState;
  //   const {
  //     dateOptions,
  //     manfBrandOptions,
  //     modelOptions,
  //     versionOptions,
  //     commonObjectOptions,
  //     tableOptions,
  //   } = nextProps;
  //   return (
  //     this.props.dateOptions !== dateOptions ||
  //     this.props.manfBrandOptions !== manfBrandOptions ||
  //     this.props.modelOptions !== modelOptions ||
  //     this.props.versionOptions !== versionOptions ||
  //     this.props.commonObjectOptions !== commonObjectOptions ||
  //     this.props.tableOptions !== tableOptions ||
  //
  //     this.state.analysisType !== analysisType
  //   );
  // }

  componentWillUpdate(nextProps, nextState) {
    const {
      analysisType: prevAnalysisType,
    } = this.state;
    const {
      startTime,
      endTime,
      analysisType,
      bodyTypes,
      models,
      versions,
      commonObjects,
    } = nextState;

    if (prevAnalysisType !== analysisType) {
      this.setState({ manfBrands: '', versions: '', commonObjects: '' });
    }

    // 型号需按所选车型进行过滤，车型改变时，重新加载型号数据
    if (this.state.models !== models && models) {
      this.props.loadVersionOptions({ startTime, endTime, bodyTypes, models });
    }

    if (this.state.versions !== versions && versions) {
      this.props.restoreObjectOptions();
    }
    if (this.state.commonObjects !== commonObjects && commonObjects) {
      this.props.restoreVersionOptions();
    }

    if (
      (
        this.state.startTime !== startTime ||
        this.state.endTime !== endTime ||
        this.state.bodyTypes !== bodyTypes
      ) && startTime && endTime
    ) {
      this.props.loadManfBrandOptions({ startTime, endTime, bodyTypes });
      this.props.loadModelOptions({ startTime, endTime, bodyTypes });
    }
  }

  componentDidUpdate(prevProps, prevState) {
    const { models } = this.state;

    // 初次加载页面时，默认加载一次表格数据
    if (!this.firstLoadTableOptions && prevState.models !== models && models) {
      this.search();
      this.firstLoadTableOptions = true;
    }
  }

  getSelectedModelIds(modelOptions) {
    return PopoverModels.findSelectedOptions(modelOptions)
      .map(model => model.id).join(',');
  }

  getParams(params = {}) {
    const {
      startTime,
      endTime,
      dateType,
      cities,
      analysisType,
      bodyTypes,
      manfBrands,
      models,
      versions,
      commonObjects,
    } = this.state;

    return {
      startTime,
      endTime,
      dateType,
      cities,
      analysisType,
      bodyTypes,
      manfBrands,
      models,
      versions: versions || commonObjects,
      ...params,
    };
  }

  getQuerystringParams() {
    return stringify(this.getParams());
  }

  search = page => {
    $('body').showLoading();
    const {
      analysisType,
      selectedCityOptions,
    } = this.state;
    const params = this.getParams(page ? { page } : {});
    this.props.loadTableOptions(params, selectedCityOptions, page, analysisType);
  }

  render() {
    const {
      tableHeight,
      analysisType,
      manfBrands,
      models,
      versions,
      commonObjects,
    } = this.state;
    const {
      dateOptions,
      cityOptions,
      bodyOptions,
      manfBrandOptions,
      modelOptions,
      versionOptions,
      commonObjectOptions,
      tableOptions,
    } = this.props;

    let submitDisabled = true;
    if (analysisType === 1 && manfBrands !== '') {
      submitDisabled = false;
    } else if (analysisType === 2 && models !== '') {
      submitDisabled = false;
    } else if (
      analysisType === 3 &&
      (versions !== '' || commonObjects !== '')
    ) {
      submitDisabled = false;
    }

    return (
      <div>
        <Toolbar color="white">
          <h2 className="mr-50">成交价查询</h2>
          <Form inline className="inline-block">
            <FormGroup
              className="mr-20"
              type="monthFrame"
              label=""
              options={dateOptions}
              onSelect={(startTime, endTime) => this.setState({ startTime, endTime })}
            />
            <FormGroup
              className="mr-20"
              type="buttonRadio"
              options={TpSearch.dateTypeOptions}
              onSelect={dateType => this.setState({ dateType })}
            />
            <FormGroup label="" className="mr-50">
              <AreaCities
                multiple
                required
                options={cityOptions}
                onSelect={(value, cities) => (
                  this.setState({ cities: value.ids, selectedCityOptions: cities })
                )}
              />
            </FormGroup>
            <Button className="btn-primary" style={{ width: 80 }} onClick={this.search} disabled={submitDisabled}>查询</Button>
          </Form>
          <DownloadExcel href={`${window.$ctx}/price/cityTpSelect/exportTpData.do?${this.getQuerystringParams()}`} className="pull-right" text="中文" />
          <DownloadExcel href={`${window.$ctx}/price/cityTpSelect/exportTpData.do?${this.getQuerystringParams()}&language=en`} className="pull-right" text="英文" />
        </Toolbar>
        <Toolbar>
          <Form inline className="inline-block">
            <FormGroup
              className="mr-20"
              type="buttonRadio"
              options={TpSearch.analysisTypeOptions}
              onSelect={analysisType => this.setState({ analysisType })}
            />
            <FormGroup
              multiple
              className="mr-20"
              type="select"
              label=""
              options={bodyOptions}
              onSelect={bodyTypes => this.setState({ bodyTypes })}
            />
            {analysisType === 1 &&
              <FormGroup
                className="mr-20"
                label=""
              >
                <ManfBrands
                  multiple
                  required
                  options={manfBrandOptions}
                  onSelect={value => this.setState({ manfBrands: value.ids })}
                />
              </FormGroup>
            }
            {(analysisType === 2 || analysisType === 3) &&
              <FormGroup
                className="mr-20"
                label=""
              >
                <PopoverModels
                  options={modelOptions}
                  onSubmit={value => this.setState({ models: value.ids })}
                />
              </FormGroup>
            }
            {analysisType === 3 &&
              <FormGroup
                className="mr-20"
                label=""
              >
                <VersionsByModels
                  disabled={!models}
                  multiple
                  required
                  options={versionOptions}
                  onSelect={value => this.setState({ versions: value.ids })}
                />
              </FormGroup>
            }
            {analysisType === 3 &&
              <FormGroup
                className="mr-20"
                label=""
              >
                <CommonObjects
                  multiple
                  required
                  options={commonObjectOptions}
                  onSelect={value => this.setState({ commonObjects: value.ids })}
                />
              </FormGroup>
            }
          </Form>
        </Toolbar>
        <div className="p-10">
          <Table
            options={tableOptions}
            scrollY={tableHeight}
            freezeHeader
            pagination={this.search}
            ppNumber={30}
          />
        </div>
      </div>
    );
  }
}
