import { connect } from 'react-redux';
import Aside from '../../components/Aside';
import { toggle } from './ducks';

function mapStateToProps(state, { pathname }) {
  const options = [
    {
      title: '生命周期',
      list: [
        {
          text: '生命周期',
          path: '#/life/life-cycle',
        },
      ],
    },
  ];

  return {
    options,
    pathname,
  };
}

export default connect(mapStateToProps, {
  toggle,
})(Aside);
