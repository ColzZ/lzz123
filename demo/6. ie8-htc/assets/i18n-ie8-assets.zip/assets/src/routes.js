import React from 'react';
import { Route, IndexRedirect } from 'react-router';
import App from './app/pages/app';
import lifeCycle from './app/pages/life-cycle';

export default (
  <Route path="/">
    <IndexRedirect to="/life/life-cycle" />
    <Route path="life" component={App}>
      <Route path="life-cycle" component={lifeCycle} />
    </Route>
  </Route>
);
