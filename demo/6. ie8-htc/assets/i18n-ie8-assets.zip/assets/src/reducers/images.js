const $ctxImages = window.$ctxImages;

// 默认图片集
export default function images() {
  return {
    carmodel: `${$ctxImages}/carmodel.png`,
    manufacturer: `${$ctxImages}/manufacturer.png`,
  };
}
