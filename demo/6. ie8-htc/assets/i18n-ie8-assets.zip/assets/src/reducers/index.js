import { combineReducers } from 'redux';
import { routerReducer as routing } from 'react-router-redux/lib/reducer';
import images from './images';
import aside from '../app/pages/app/containers/Aside/ducks';
// import tpSearch from '../app/pages/tp-search/reducer';
// import msrpSearch from '../app/pages/msrp-search/reducer';
// import newEnergyPage from '../app/pages/new-energy-page/reducer';
import lifeCycle from '../app/pages/life-cycle/reducer';

export default combineReducers({
  routing,
  images,
  aside,
  // tpSearch,
  // msrpSearch,
  // newEnergyPage,
  lifeCycle,
});
