import * as api from './api';

function createThunkMiddleware() {
  return ({ dispatch }) => next => action => {
    const { type, endpoint } = action;

    if (Object.prototype.toString.call(type) === '[object Array]' && endpoint) {
      api[endpoint.type !== 'POST' ? 'getDataFromServer' : 'postDataToServer'](dispatch, action);

      return undefined;
    }

    return next(action);
  };
}

const thunk = createThunkMiddleware();
thunk.withExtraArgument = createThunkMiddleware;

export default thunk;
