/*
  MIT License http://www.opensource.org/licenses/mit-license.php
  Author Tobias Koppers @sokra
*/
const ConstDependency = require('webpack/lib/dependencies/ConstDependency');
const NullFactory = require('webpack/lib/NullFactory');
const MissingLocalizationError = require('./MissingLocalizationError');
const fs = require('fs');

let odd = false;

/**
 *
 * @param {object}  localization
 * @param {string}  string key
 * @returns {*}
 */
function byString(obj, sKey) {
  let object = obj;
  const stringKey = sKey.replace(/^\./, ''); // strip a leading dot

  const keysArray = stringKey.split('.');
  for (let i = 0, length = keysArray.length; i < length; i += 1) {
    const key = keysArray[i];
    if (key in object) {
      object = object[key];
    } else {
      return undefined;
    }
  }

  return object;
}

/**
 *
 * @param {object}  localization
 * @returns {Function}
 */
function makeLocalizeFunction(localization, nested) {
  return function localizeFunction(key) {
    return nested ? byString(localization, key) : localization[key];
  };
}

function makeLocalize(localization, nested) {
  if (localization) {
    if (typeof localization === 'function') {
      return localization;
    }
    return makeLocalizeFunction(localization, !!nested);
  }
  return null;
}

/**
 *
 * @param {object|function} localization
 * @param {object|string} Options object or obselete functionName string
 * @constructor
 */
function I18nPlugin(localization, opts, failOnMissing) {
  let options = opts;
  // Backward-compatiblility
  if (typeof options === 'string') {
    options = {
      functionName: options,
    };
  }

  if (failOnMissing) {
    options.failOnMissing = failOnMissing;
  }

  this.options = options || {};
  this.functionName = this.options.functionName || '__';
  this.failOnMissing = !!this.options.failOnMissing;

  if (localization && typeof localization === 'string') {
    try {
      const localizationJson = JSON.parse(fs.readFileSync(localization));
      this.localization = makeLocalize(localizationJson, !!this.options.nested);
    } catch (e) {
      console.log('语言包格式错误', localization);
    }

    fs.watch(localization, eventType => {
      if (eventType !== 'change') return;

      odd = !odd;
      if (odd) return;

      try {
        const content = fs.readFileSync(localization);
        const localizationJson = JSON.parse(content);
        this.localization = makeLocalize(localizationJson, !!this.options.nested);
        console.log('语言包被修改', localization);
      } catch (e) {
        return;
      }
    });
  } else {
    this.localization = makeLocalize(localization, !!this.options.nested);
  }
}

module.exports = I18nPlugin;

I18nPlugin.prototype.apply = function (compiler) {
  const self = this;
  let localization = this.localization;
  const failOnMissing = this.failOnMissing;

  compiler.plugin('compilation', compilation => {
    compilation.dependencyFactories.set(ConstDependency, new NullFactory());
    compilation.dependencyTemplates.set(ConstDependency, new ConstDependency.Template());
  });

  compiler.parser.plugin(`call ${this.functionName}`, function (expr) {
    let param;
    let defaultValue;
    let result;

    switch (expr.arguments.length) {
      // case 2:
      // param = this.evaluateExpression(expr.arguments[1]);
      // if(!param.isString()) return;
      // param = param.string;
      // defaultValue = this.evaluateExpression(expr.arguments[0]);
      // if(!defaultValue.isString()) return;
      // defaultValue = defaultValue.string;
      // break;
      case 1:
        param = this.evaluateExpression(expr.arguments[0]);
        if (!param.isString()) return;
        defaultValue = param = param.string;
        break;
      default:
        if (self.options.watch) {
          param = this.evaluateExpression(expr.arguments[0]);
          if (!param.isString()) return;
          defaultValue = param = param.string;
          break;
        }
        return;
    }

    if (self.options.watch) localization = self.localization;

    result = localization ? localization(param) : defaultValue;

    if (self.options.watch && result && expr.arguments.length > 1) {
      const [, ...params] = expr.arguments;
      if (typeof result === 'string') {
        params.forEach(({ value }) => {
          // %s 输出替换字符串
          result = result.replace('%s', value);
          // %% 输出 %
          result = result.replace('%%', '%');
        });
      } else if (Array.isArray(result)) {
        result = result[params[0].value];
      }
    }

    if (typeof result === 'undefined') {
      let error = this.state.module[__dirname];

      if (!error) {
        error = this.state.module[__dirname] =
          new MissingLocalizationError(this.state.module, param, defaultValue);

        if (failOnMissing) {
          this.state.module.errors.push(error);
        } else {
          this.state.module.warnings.push(error);
        }
      } else if (error.requests.indexOf(param) < 0) {
        error.add(param, defaultValue);
      }

      result = defaultValue;
    }
    const dep = new ConstDependency(JSON.stringify(result), expr.range);
    dep.loc = expr.loc;
    this.state.current.addDependency(dep);

    return;
  });
};
