module.exports = {
  // 是否支持 IE8
  ie8: true,

  // 主机
  host: 'localhost',

  // 端口
  port: 3000,

  // 开发模式公共资源路径
  devPublicPath: 'assets',

  // 生产模式公共资源路径
  prodPublicPath: '',

  // 国际化
  i18n: {
    // 语言包目录路径
    path: './src/app/i18n',

    // 是否打开文件变化监控模式
    watch: false,
  },

  // 由于 IE8 不支持热替换模式，这个配置要在
  // ie8: false 时才会生效
  hmr: true,
};
